import { useState } from "react";
import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import Dashboard from "@/pages/dashboard";
import Log from "@/pages/log";
import History from "@/pages/history";
import Login from "@/pages/login";
import Settings from "@/pages/settings";
import Medications from "@/pages/medications";
import Admin from "@/pages/admin";
import NotFound from "@/pages/not-found";
import { AuthContext, getStoredAuth, type AuthState } from "@/lib/auth";
import { AgeProvider } from "@/lib/age-context";
import { ThemeProvider } from "@/lib/theme-context";

const queryClient = new QueryClient();

function ProtectedRouter({ auth }: { auth: AuthState }) {
  if (!auth.token) {
    return <Redirect to="/login" />;
  }

  return (
    <AgeProvider>
    <Layout>
      <Switch>
        <Route path="/"             component={Dashboard} />
        <Route path="/log"          component={Log} />
        <Route path="/history"      component={History} />
        <Route path="/settings"     component={Settings} />
        <Route path="/medications"  component={Medications} />
        <Route path="/admin">
          {auth.isAdmin ? <Admin /> : <Redirect to="/" />}
        </Route>
        <Route component={NotFound} />
      </Switch>
    </Layout>
    </AgeProvider>
  );
}

function App() {
  const [auth, setAuth] = useState<AuthState>(getStoredAuth);

  return (
    <ThemeProvider>
      <AuthContext.Provider value={{ auth, setAuth }}>
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Switch>
                <Route path="/login" component={Login} />
                <Route>
                  <ProtectedRouter auth={auth} />
                </Route>
              </Switch>
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </QueryClientProvider>
      </AuthContext.Provider>
    </ThemeProvider>
  );
}

export default App;
