import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { Download, FileText, Filter } from "lucide-react";

interface DateRangeDownloadProps {
  /** Show just icons on small screens */
  compact?: boolean;
}

export function DateRangeDownload({ compact = false }: DateRangeDownloadProps) {
  const { auth }   = useAuth();
  const { toast }  = useToast();
  const [open, setOpen]   = useState(false);
  const [from, setFrom]   = useState("");
  const [to,   setTo]     = useState("");

  const buildQs = () => {
    const params = new URLSearchParams();
    if (from) params.set("from", from);
    if (to)   params.set("to",   to);
    return params.toString() ? `?${params.toString()}` : "";
  };

  const rangeLabel = () => {
    if (from && to)  return `${from} → ${to}`;
    if (from)        return `From ${from}`;
    if (to)          return `To ${to}`;
    return "All time";
  };

  const download = async (endpoint: string, defaultName: string) => {
    setOpen(false);
    try {
      const res = await fetch(`/api/export/${endpoint}${buildQs()}`, {
        headers: { Authorization: `Bearer ${auth.token}` },
      });
      if (!res.ok) throw new Error((await res.json()).error ?? "Export failed");
      const blob  = await res.blob();
      const url   = URL.createObjectURL(blob);
      const a     = document.createElement("a");
      a.href      = url;
      const match = (res.headers.get("Content-Disposition") ?? "").match(/filename="([^"]+)"/);
      a.download  = match?.[1] ?? defaultName;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast({
        title: "Download failed",
        description: err instanceof Error ? err.message : "Could not export.",
        variant: "destructive",
      });
    }
  };

  const hasFilter = from || to;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={`gap-2 ${hasFilter ? "border-primary/40 text-primary bg-primary/5" : ""}`}
        >
          <Filter className="w-3.5 h-3.5" />
          {!compact && <span className="hidden sm:inline">Download{hasFilter ? ` · ${rangeLabel()}` : ""}</span>}
          {compact && hasFilter && <span className="hidden sm:inline text-xs">{rangeLabel()}</span>}
        </Button>
      </PopoverTrigger>

      <PopoverContent className="w-72 p-4" align="end">
        <p className="text-sm font-semibold text-foreground mb-3">Download options</p>

        {/* Date range */}
        <div className="space-y-3 mb-4">
          <div className="space-y-1">
            <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              From (optional)
            </Label>
            <Input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="bg-muted/50 text-sm"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              To (optional)
            </Label>
            <Input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="bg-muted/50 text-sm"
            />
          </div>
          {hasFilter && (
            <button
              onClick={() => { setFrom(""); setTo(""); }}
              className="text-xs text-primary hover:underline"
            >
              Clear filter (all time)
            </button>
          )}
        </div>

        <p className="text-xs text-muted-foreground mb-3">
          {hasFilter ? `Exporting: ${rangeLabel()}` : "Exporting all readings"}
        </p>

        {/* Download buttons */}
        <div className="flex flex-col gap-2">
          <Button
            size="sm"
            className="w-full justify-start gap-2"
            onClick={() => download("pdf", "bp-report.pdf")}
          >
            <FileText className="w-4 h-4" />
            PDF Report
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="w-full justify-start gap-2"
            onClick={() => download("csv", "bp-history.csv")}
          >
            <Download className="w-4 h-4" />
            CSV Spreadsheet
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
