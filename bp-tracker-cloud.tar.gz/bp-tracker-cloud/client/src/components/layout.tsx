import { Link, useLocation } from "wouter";
import { Activity, PlusCircle, Clock, LogOut, User, Settings, ShieldCheck, Pill } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { clearAuth } from "@/lib/auth";
import { setAuthTokenGetter } from "@/api";
import { useQueryClient } from "@tanstack/react-query";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location]        = useLocation();
  const { auth, setAuth } = useAuth();
  const queryClient       = useQueryClient();

  const handleLogout = () => {
    clearAuth();
    setAuthTokenGetter(null);
    setAuth({ token: null, username: null, isAdmin: false });
    queryClient.clear();
  };

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background">

      {/* ── Sidebar ── */}
      <nav className="md:w-56 border-b md:border-b-0 md:border-r border-border bg-card md:min-h-[100dvh] p-3 flex flex-col shrink-0 sticky top-0 md:static z-10 shadow-sm md:shadow-none">

        {/* Logo */}
        <div className="mb-5 px-3 pt-2 pb-4 border-b border-border flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Activity className="h-4 w-4 text-primary" />
          </div>
          <h1 className="font-bold tracking-tight text-base text-foreground">Vitals</h1>
        </div>

        {/* Main nav */}
        <div className="flex md:flex-col gap-1 overflow-x-auto pb-2 md:pb-0 hide-scrollbar flex-1">
          <NavLink href="/"        active={location === "/"}        icon={<Activity   className="w-4 h-4" />}>Dashboard</NavLink>
          <NavLink href="/log"     active={location === "/log"}     icon={<PlusCircle className="w-4 h-4" />}>Log Reading</NavLink>
          <NavLink href="/history"     active={location === "/history"}     icon={<Clock      className="w-4 h-4" />}>History</NavLink>
          <NavLink href="/medications" active={location === "/medications"} icon={<Pill       className="w-4 h-4" />}>Medications</NavLink>

          {/* Divider before account links on desktop */}
          <div className="hidden md:block my-1 border-t border-border/60" />

          <NavLink href="/settings" active={location === "/settings"} icon={<Settings className="w-4 h-4" />}>Settings</NavLink>

          {auth.isAdmin && (
            <NavLink href="/admin" active={location === "/admin"} icon={<ShieldCheck className="w-4 h-4" />}>
              Admin
            </NavLink>
          )}
        </div>

        {/* User strip at bottom of sidebar — desktop */}
        <div className="mt-auto pt-3 border-t border-border hidden md:block">
          <div className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-muted/60 transition-colors">
            <div className="flex items-center gap-2 text-sm text-muted-foreground min-w-0">
              <div className="w-6 h-6 rounded-full bg-muted border border-border flex items-center justify-center flex-shrink-0">
                <User className="w-3 h-3" />
              </div>
              <span className="truncate text-xs font-medium">{auth.username}</span>
            </div>
            <button
              onClick={handleLogout}
              className="text-muted-foreground hover:text-foreground transition-colors p-1 rounded-md hover:bg-muted ml-1"
              title="Sign out"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Mobile logout */}
        <button
          onClick={handleLogout}
          className="md:hidden flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-colors whitespace-nowrap mt-1"
        >
          <LogOut className="w-4 h-4" />
          Sign out
        </button>
      </nav>

      {/* ── Main content ── */}
      <main className="flex-1 w-full max-w-5xl mx-auto p-4 md:p-8 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}

function NavLink({
  href, active, children, icon,
}: {
  href: string; active: boolean; children: React.ReactNode; icon: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
        active
          ? "bg-primary/10 text-primary"
          : "text-muted-foreground hover:bg-muted hover:text-foreground"
      }`}
    >
      {icon}
      {children}
    </Link>
  );
}
