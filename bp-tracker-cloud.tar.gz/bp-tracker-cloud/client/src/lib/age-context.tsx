import { createContext, useContext, useState, useEffect } from "react";
import { useTheme } from "./theme-context";
import { useAuth } from "@/lib/auth";
import { calcAge } from "@/lib/bp-utils";

interface AgeContextValue {
  age: number | null;
  dateOfBirth: string | null;
  setDateOfBirth: (dob: string | null) => void;
}

const AgeContext = createContext<AgeContextValue>({
  age: null,
  dateOfBirth: null,
  setDateOfBirth: () => {},
});

export function AgeProvider({ children }: { children: React.ReactNode }) {
  const { auth } = useAuth();
  const { setTheme } = useTheme();
  const [dateOfBirth, setDateOfBirth] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!auth.token) return;
    fetch("/api/account/settings", {
      headers: { Authorization: `Bearer ${auth.token}` },
    })
      .then((r) => r.json())
      .then((data: { dateOfBirth?: string | null; theme?: string }) => {
        setDateOfBirth(data.dateOfBirth ?? null);
        if (data.theme) setTheme(data.theme as 'light' | 'dark' | 'system');
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
  }, [auth.token]);

  const age = calcAge(dateOfBirth);

  return (
    <AgeContext.Provider value={{ age, dateOfBirth, setDateOfBirth }}>
      {children}
    </AgeContext.Provider>
  );
}

export function useAge() {
  return useContext(AgeContext);
}
