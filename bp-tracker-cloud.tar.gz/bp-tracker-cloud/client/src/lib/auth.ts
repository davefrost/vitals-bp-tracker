import { createContext, useContext } from "react";

export interface AuthState {
  token: string | null;
  username: string | null;
  isAdmin: boolean;
  userId?: number;
}

const TOKEN_KEY    = "bp_token";
const USERNAME_KEY = "bp_username";
const ADMIN_KEY    = "bp_is_admin";
const USERID_KEY   = "bp_user_id";

export function getStoredAuth(): AuthState {
  try {
    const uid = localStorage.getItem(USERID_KEY);
    return {
      token:    localStorage.getItem(TOKEN_KEY),
      username: localStorage.getItem(USERNAME_KEY),
      isAdmin:  localStorage.getItem(ADMIN_KEY) === "true",
      userId:   uid ? parseInt(uid, 10) : undefined,
    };
  } catch {
    return { token: null, username: null, isAdmin: false };
  }
}

export function storeAuth(token: string, username: string, isAdmin: boolean, userId?: number): void {
  localStorage.setItem(TOKEN_KEY,    token);
  localStorage.setItem(USERNAME_KEY, username);
  localStorage.setItem(ADMIN_KEY,    String(isAdmin));
  if (userId !== undefined) localStorage.setItem(USERID_KEY, String(userId));
}

export function clearAuth(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USERNAME_KEY);
  localStorage.removeItem(ADMIN_KEY);
  localStorage.removeItem(USERID_KEY);
}

export const AuthContext = createContext<{
  auth: AuthState;
  setAuth: (auth: AuthState) => void;
}>({
  auth: { token: null, username: null, isAdmin: false, userId: undefined },
  setAuth: () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}
