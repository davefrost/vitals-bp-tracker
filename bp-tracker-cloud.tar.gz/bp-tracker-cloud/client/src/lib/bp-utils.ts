/**
 * BP category utilities — mirrors server/src/lib/bp-categories.ts
 * Over-80 thresholds follow NHS/NICE NG136 and British Heart Foundation guidance.
 */

export type BpCategory =
  | "Normal"
  | "Acceptable for Age"
  | "Elevated"
  | "High Stage 1"
  | "High Stage 2"
  | "Hypertensive Crisis";

export function calcAge(dateOfBirth: string | null | undefined): number | null {
  if (!dateOfBirth) return null;
  const dob   = new Date(dateOfBirth);
  if (isNaN(dob.getTime())) return null;
  const today = new Date();
  let age     = today.getFullYear() - dob.getFullYear();
  const m     = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

export function getCategoryName(
  systolic: number,
  diastolic: number,
  age?: number | null,
): BpCategory {
  if (systolic > 180 || diastolic > 120) return "Hypertensive Crisis";

  if (age !== null && age !== undefined && age >= 80) {
    if (systolic >= 150 || diastolic >= 90) return "High Stage 2";
    if (systolic >= 140)                    return "High Stage 1";
    if (systolic >= 130 || diastolic >= 80) return "Acceptable for Age";
    if (systolic >= 120 && diastolic < 80)  return "Elevated";
    return "Normal";
  }

  if (systolic >= 140 || diastolic >= 90)  return "High Stage 2";
  if (systolic >= 130 || diastolic >= 80)  return "High Stage 1";
  if (systolic >= 120 && diastolic < 80)   return "Elevated";
  return "Normal";
}

export function getCategoryStyles(
  systolic: number,
  diastolic: number,
  age?: number | null,
): string {
  const cat = getCategoryName(systolic, diastolic, age);
  switch (cat) {
    case "Normal":             return "bg-emerald-100 text-emerald-800 border-emerald-200";
    case "Acceptable for Age": return "bg-sky-100 text-sky-800 border-sky-200";
    case "Elevated":           return "bg-yellow-100 text-yellow-800 border-yellow-200";
    case "High Stage 1":       return "bg-orange-100 text-orange-800 border-orange-200";
    case "High Stage 2":       return "bg-red-100 text-red-800 border-red-200";
    case "Hypertensive Crisis":return "bg-purple-100 text-purple-800 border-purple-200";
  }
}

export function getSystolicColor(
  systolic: number,
  diastolic: number,
  age?: number | null,
): string {
  const cat = getCategoryName(systolic, diastolic, age);
  switch (cat) {
    case "Normal":             return "text-foreground";
    case "Acceptable for Age": return "text-sky-600";
    case "Elevated":           return "text-yellow-600";
    case "High Stage 1":       return "text-primary";
    case "High Stage 2":       return "text-red-600";
    case "Hypertensive Crisis":return "text-purple-600";
  }
}

export function formatDate(dateStr: string) {
  return new Intl.DateTimeFormat("en-GB", {
    day: "numeric", month: "short", year: "numeric",
  }).format(new Date(dateStr));
}

export function formatTime(dateStr: string) {
  return new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit", minute: "2-digit",
  }).format(new Date(dateStr));
}
