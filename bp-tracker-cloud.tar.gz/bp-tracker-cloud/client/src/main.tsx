import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { setAuthTokenGetter } from "@/api";
import { getStoredAuth } from "@/lib/auth";

// Restore auth token from localStorage so API calls are authenticated on page reload
const { token } = getStoredAuth();
if (token) {
  setAuthTokenGetter(() => token);
}

createRoot(document.getElementById("root")!).render(<App />);
