import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { Loader2, Shield, ShieldOff, Trash2, KeyRound, Users } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

interface AdminUser {
  id: number;
  username: string;
  displayName: string | null;
  isAdmin: boolean;
  createdAt: string;
  readingCount: number;
}

export default function Admin() {
  const { auth } = useAuth();
  const { toast } = useToast();
  const [users, setUsers]     = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);

  // Reset password dialog state
  const [resetUserId, setResetUserId]     = useState<number | null>(null);
  const [resetUsername, setResetUsername] = useState("");
  const [newPassword, setNewPassword]     = useState("");
  const [resetting, setResetting]         = useState(false);

  const fetchUsers = () => {
    fetch("/api/admin/users", { headers: { Authorization: `Bearer ${auth.token}` } })
      .then((r) => r.json())
      .then((data: AdminUser[]) => { setUsers(data); setLoading(false); })
      .catch(() => { toast({ title: "Error loading users", variant: "destructive" }); setLoading(false); });
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleToggleAdmin = async (user: AdminUser) => {
    try {
      const res = await fetch(`/api/admin/users/${user.id}/toggle-admin`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${auth.token}` },
      });
      if (!res.ok) throw new Error((await res.json()).error);
      toast({ title: `${user.username} is ${user.isAdmin ? "no longer" : "now"} an admin` });
      fetchUsers();
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed", variant: "destructive" });
    }
  };

  const handleDelete = async (userId: number) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${auth.token}` },
      });
      if (!res.ok) throw new Error((await res.json()).error);
      toast({ title: "User deleted" });
      fetchUsers();
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed", variant: "destructive" });
    }
  };

  const handleResetPassword = async () => {
    if (!resetUserId || newPassword.length < 6) return;
    setResetting(true);
    try {
      const res = await fetch(`/api/admin/users/${resetUserId}/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.token}` },
        body: JSON.stringify({ newPassword }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      toast({ title: `Password reset for ${resetUsername}` });
      setResetUserId(null);
      setNewPassword("");
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed", variant: "destructive" });
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-12">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-foreground">Admin Panel</h2>
        <p className="text-sm text-muted-foreground mt-0.5">Manage users and account access.</p>
      </div>

      <Card className="border shadow-sm">
        <CardHeader className="pb-2 pt-5 px-6">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" /> Users ({users.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="px-6 pb-6">
          {loading ? (
            <div className="space-y-3">
              {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
            </div>
          ) : (
            <div className="space-y-2">
              {users.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm text-foreground">{user.username}</span>
                      {user.displayName && (
                        <span className="text-xs text-muted-foreground">({user.displayName})</span>
                      )}
                      {user.isAdmin && (
                        <Badge variant="outline" className="text-xs px-2 py-0 bg-primary/10 border-primary/20 text-primary">
                          Admin
                        </Badge>
                      )}
                      {user.id === auth.userId && (
                        <Badge variant="outline" className="text-xs px-2 py-0 bg-muted text-muted-foreground">
                          You
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {user.readingCount} reading{user.readingCount !== 1 ? "s" : ""} · joined {new Date(user.createdAt).toLocaleDateString("en-GB", { month: "short", year: "numeric" })}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Reset password */}
                    <Dialog open={resetUserId === user.id} onOpenChange={(open) => { if (!open) { setResetUserId(null); setNewPassword(""); } }}>
                      <DialogTrigger asChild>
                        <Button
                          variant="ghost" size="icon"
                          className="text-muted-foreground hover:text-foreground"
                          onClick={() => { setResetUserId(user.id); setResetUsername(user.username); }}
                          title="Reset password"
                        >
                          <KeyRound className="w-4 h-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Reset password for {resetUsername}</DialogTitle>
                          <DialogDescription>Set a new temporary password. The user should change it after logging in.</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-2 py-2">
                          <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">New Password</Label>
                          <Input
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="At least 6 characters"
                            className="bg-muted/50"
                          />
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => { setResetUserId(null); setNewPassword(""); }}>Cancel</Button>
                          <Button onClick={handleResetPassword} disabled={resetting || newPassword.length < 6}>
                            {resetting && <Loader2 className="mr-2 h-3 w-3 animate-spin" />}
                            Reset Password
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    {/* Toggle admin — not for self */}
                    {user.id !== Number(auth.userId) && (
                      <Button
                        variant="ghost" size="icon"
                        className="text-muted-foreground hover:text-foreground"
                        onClick={() => handleToggleAdmin(user)}
                        title={user.isAdmin ? "Remove admin" : "Make admin"}
                      >
                        {user.isAdmin ? <ShieldOff className="w-4 h-4" /> : <Shield className="w-4 h-4" />}
                      </Button>
                    )}

                    {/* Delete — not for self */}
                    {user.id !== Number(auth.userId) && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete {user.username}?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete the user and all {user.readingCount} of their readings. This cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(user.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                              Delete User
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
