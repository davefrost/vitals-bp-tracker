import {
  useGetDashboardSummary, getGetDashboardSummaryQueryKey,
  useGetReadingTrend,      getGetReadingTrendQueryKey,
  useGetCategoryBreakdown, getGetCategoryBreakdownQueryKey,
  useListReadings,         getListReadingsQueryKey,
} from "@/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { PlusCircle, Heart, Calendar } from "lucide-react";
import { DateRangeDownload } from "@/components/date-range-download";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip as RechartsTooltip, ResponsiveContainer,
  ReferenceLine,
  PieChart, Pie, Cell, Legend,
} from "recharts";
import {
  getCategoryStyles, getCategoryName, getSystolicColor,
  formatDate, formatTime,
} from "@/lib/bp-utils";
import { useAuth } from "@/lib/auth";
import { useAge } from "@/lib/age-context";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { data: summary, isLoading: loadingSummary } =
    useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const { data: trends, isLoading: loadingTrends } =
    useGetReadingTrend({ days: 30 }, { query: { queryKey: getGetReadingTrendQueryKey({ days: 30 }) } });
  const { data: categories, isLoading: loadingCategories } =
    useGetCategoryBreakdown({ query: { queryKey: getGetCategoryBreakdownQueryKey() } });
  const { data: readings } =
    useListReadings({ limit: 500 }, { query: { queryKey: getListReadingsQueryKey({ limit: 500 }) } });

  const { auth } = useAuth();
  const { age }  = useAge();
  const { toast } = useToast();

  const hasReadings = summary?.totalReadings && summary.totalReadings > 0;

  if (loadingSummary) {
    return (
      <div className="space-y-5 animate-in fade-in duration-500">
        <Skeleton className="h-8 w-40 rounded-xl" />
        <Skeleton className="h-44 w-full rounded-2xl" />
        <div className="grid grid-cols-3 gap-3">
          <Skeleton className="h-24 rounded-2xl" />
          <Skeleton className="h-24 rounded-2xl" />
          <Skeleton className="h-24 rounded-2xl" />
        </div>
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    );
  }

  if (!hasReadings || !summary) {
    return (
      <div className="h-[70vh] flex flex-col items-center justify-center text-center animate-in fade-in zoom-in-95 duration-500 max-w-sm mx-auto">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <PlusCircle className="w-9 h-9 text-primary" />
        </div>
        <h2 className="text-2xl font-bold tracking-tight text-foreground mb-2">Welcome to Vitals</h2>
        <p className="text-muted-foreground text-sm leading-relaxed mb-8">
          Log your first reading to see your health summary, trends, and personalised advice.
        </p>
        <Link
          href="/log"
          className="bg-primary text-primary-foreground hover:bg-primary/90 h-11 px-8 rounded-xl flex items-center justify-center font-semibold text-sm shadow-sm transition-all hover:-translate-y-0.5"
        >
          Log First Reading
        </Link>
      </div>
    );
  }

  const latest = summary.latestReading!;
  const sysColor = getSystolicColor(latest.systolic, latest.diastolic, age);
  const catStyles = getCategoryStyles(latest.systolic, latest.diastolic, age);
  const catName   = getCategoryName(latest.systolic, latest.diastolic, age);

  return (
    <div className="space-y-4 animate-in fade-in duration-500 pb-12">

      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-2">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-foreground">Overview</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            {new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(new Date())}
            &nbsp;·&nbsp; {summary.totalReadings} readings
          </p>
        </div>
        <DateRangeDownload />
      </div>

      {/* ── Main reading card ── */}
      <Card className="border shadow-sm hover-elevate">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                Latest · {formatDate(latest.recordedAt)}
              </p>
              {/* Big monospace BP number */}
              <div className="flex items-baseline gap-1 mb-4">
                <span className={`bp-number text-7xl font-medium ${sysColor}`}>
                  {latest.systolic}
                </span>
                <span className="bp-number text-4xl font-light text-border mx-1">/</span>
                <span className="bp-number text-7xl font-medium text-foreground/60">
                  {latest.diastolic}
                </span>
                <span className="text-sm text-muted-foreground ml-2 mb-2">mmHg</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="outline" className={`px-3 py-1 rounded-full text-xs font-semibold border ${catStyles}`}>
                  {catName}
                </Badge>
                {latest.pulse && (
                  <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <span className="pulse-dot" />
                    {latest.pulse} bpm
                  </span>
                )}
              </div>
            </div>

            {/* Average block */}
            <div className="sm:text-right border-t sm:border-t-0 pt-4 sm:pt-0">
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
                All-time avg
              </p>
              <div className="flex items-baseline gap-1 sm:justify-end">
                <span className="bp-number text-3xl font-medium text-foreground">
                  {Math.round(summary.avgSystolic ?? 0)}
                </span>
                <span className="bp-number text-xl text-muted-foreground font-light">/</span>
                <span className="bp-number text-3xl font-medium text-foreground/60">
                  {Math.round(summary.avgDiastolic ?? 0)}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{summary.totalReadings} readings</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── Stat cards ── */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Systolic avg",  value: Math.round(summary.avgSystolic ?? 0),  unit: "mmHg" },
          { label: "Diastolic avg", value: Math.round(summary.avgDiastolic ?? 0), unit: "mmHg" },
          { label: "Pulse avg",     value: Math.round(summary.avgPulse ?? 0),     unit: "bpm"  },
        ].map((s) => (
          <Card key={s.label} className="border shadow-sm">
            <CardContent className="p-4 sm:p-5">
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">{s.label}</p>
              <p className="bp-number text-2xl sm:text-3xl font-medium text-foreground">
                {s.value || "—"}
                <span className="text-xs font-sans font-normal text-muted-foreground ml-1">{s.unit}</span>
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── Insight card ── */}
      {summary.advice && (
        <Card className="border border-primary/20 bg-primary/5 shadow-none">
          <CardContent className="p-5 sm:p-6">
            <p className="text-sm font-semibold text-primary mb-2">Health Insight</p>
            <p className="text-sm text-foreground/80 leading-relaxed">{summary.advice}</p>
            {summary.tips.length > 0 && (
              <ul className="mt-3 space-y-1.5">
                {summary.tips.map((tip, i) => (
                  <li key={i} className="flex gap-2 text-sm text-muted-foreground">
                    <span className="text-primary/50 font-bold mt-0.5 flex-shrink-0">·</span>
                    {tip}
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── Charts row ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 border shadow-sm">
          <CardHeader className="pb-2 pt-5 px-6">
            <CardTitle className="text-sm font-semibold text-foreground">30-Day Trend</CardTitle>
          </CardHeader>
          <CardContent className="px-6 pb-5">
            {loadingTrends ? (
              <Skeleton className="h-[240px] w-full" />
            ) : trends && trends.length > 0 ? (
              <div className="h-[240px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={[...trends].reverse()} margin={{ top: 5, right: 16, bottom: 5, left: -24 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis
                      dataKey="date"
                      tickFormatter={(v) => new Date(v).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      dy={8}
                    />
                    <YAxis
                      domain={["dataMin - 10", "dataMax + 10"]}
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <RechartsTooltip
                      contentStyle={{
                        borderRadius: "10px",
                        border: "1px solid hsl(var(--border))",
                        boxShadow: "var(--shadow-md)",
                        fontSize: "12px",
                      }}
                      labelFormatter={(v) =>
                        new Date(v).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" })
                      }
                    />
                    <Line
                      type="monotone"
                      dataKey="systolic"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={2.5}
                      dot={false}
                      activeDot={{ r: 5, strokeWidth: 0 }}
                      name="Systolic"
                    />
                    <Line
                      type="monotone"
                      dataKey="diastolic"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2.5}
                      dot={false}
                      activeDot={{ r: 5, strokeWidth: 0 }}
                      name="Diastolic"
                    />
                    {/* Systolic thresholds */}
                    <ReferenceLine
                      y={age !== null && age >= 80 ? 150 : 140}
                      stroke="#b91c1c"
                      strokeDasharray="5 3"
                      strokeWidth={1.5}
                      label={{ value: age !== null && age >= 80 ? "150 (High)" : "140 (High)", position: "insideTopRight", fontSize: 10, fill: "#b91c1c" }}
                    />
                    <ReferenceLine
                      y={130}
                      stroke="#c94030"
                      strokeDasharray="4 4"
                      strokeWidth={1}
                      label={{ value: "130", position: "insideTopRight", fontSize: 10, fill: "#c94030" }}
                    />
                    <ReferenceLine
                      y={120}
                      stroke="#16a34a"
                      strokeDasharray="4 4"
                      strokeWidth={1}
                      label={{ value: "120 (Normal)", position: "insideTopRight", fontSize: 10, fill: "#16a34a" }}
                    />
                    {/* Diastolic threshold */}
                    <ReferenceLine
                      y={age !== null && age >= 80 ? 90 : 90}
                      stroke="#94a3b8"
                      strokeDasharray="3 3"
                      strokeWidth={1}
                      label={{ value: "90", position: "insideBottomRight", fontSize: 10, fill: "#94a3b8" }}
                    />
                    <ReferenceLine
                      y={80}
                      stroke="#16a34a"
                      strokeDasharray="3 3"
                      strokeWidth={1}
                      label={{ value: "80", position: "insideBottomRight", fontSize: 10, fill: "#16a34a" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[240px] flex items-center justify-center text-muted-foreground text-sm">
                Not enough data yet
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border shadow-sm">
          <CardHeader className="pb-2 pt-5 px-6">
            <CardTitle className="text-sm font-semibold text-foreground">Distribution</CardTitle>
          </CardHeader>
          <CardContent className="px-6 pb-5">
            {loadingCategories ? (
              <Skeleton className="h-[240px] w-full" />
            ) : categories && categories.length > 0 ? (
              <div className="h-[240px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categories}
                      cx="50%"
                      cy="44%"
                      innerRadius={56}
                      outerRadius={76}
                      paddingAngle={4}
                      dataKey="count"
                      nameKey="category"
                    >
                      {categories.map((entry, i) => {
                        let fill = entry.color;
                        if (fill === "green")  fill = "#16a34a";
                        if (fill === "yellow") fill = "#ca8a04";
                        if (fill === "orange") fill = "#c94030";
                        if (fill === "red")    fill = "#b91c1c";
                        if (fill === "purple") fill = "#7c3aed";
                        return <Cell key={`cell-${i}`} fill={fill} />;
                      })}
                    </Pie>
                    <RechartsTooltip
                      contentStyle={{
                        borderRadius: "10px",
                        border: "1px solid hsl(var(--border))",
                        boxShadow: "var(--shadow-md)",
                        fontSize: "12px",
                      }}
                    />
                    <Legend
                      verticalAlign="bottom"
                      height={36}
                      iconType="circle"
                      wrapperStyle={{ fontSize: "11px" }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[240px] flex items-center justify-center text-muted-foreground text-sm">
                Not enough data
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Recent readings table ── */}
      {readings && readings.length > 0 && (
        <Card className="border shadow-sm">
          <CardHeader className="pb-2 pt-5 px-6">
            <CardTitle className="text-sm font-semibold text-foreground">Recent Readings</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              Use the <strong>Download</strong> button above to export a PDF report for your GP or a CSV spreadsheet — with optional date filtering.
            </p>
          </CardHeader>
          <CardContent className="px-6 pb-5">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left border-b border-border">
                    <th className="pb-2 pr-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Date</th>
                    <th className="pb-2 pr-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Systolic</th>
                    <th className="pb-2 pr-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Diastolic</th>
                    <th className="pb-2 pr-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Pulse</th>
                    <th className="pb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Category</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {readings.slice(0, 10).map((r) => (
                    <tr key={r.id} className="hover:bg-muted/40 transition-colors">
                      <td className="py-2.5 pr-4 text-muted-foreground text-xs whitespace-nowrap">
                        <span className="flex items-center gap-1.5">
                          <Calendar className="w-3 h-3" />
                          {formatDate(r.recordedAt)} {formatTime(r.recordedAt)}
                        </span>
                      </td>
                      <td className={`py-2.5 pr-4 bp-number font-medium text-base ${getSystolicColor(r.systolic, r.diastolic, age)}`}>
                        {r.systolic}
                      </td>
                      <td className="py-2.5 pr-4 bp-number font-medium text-base text-foreground/70">
                        {r.diastolic}
                      </td>
                      <td className="py-2.5 pr-4 text-muted-foreground text-sm">
                        {r.pulse ? (
                          <span className="flex items-center gap-1">
                            <Heart className="w-3 h-3 text-primary/60" /> {r.pulse}
                          </span>
                        ) : "—"}
                      </td>
                      <td className="py-2.5">
                        <Badge variant="outline" className={`text-xs px-2 py-0 rounded-full border ${getCategoryStyles(r.systolic, r.diastolic, age)}`}>
                          {getCategoryName(r.systolic, r.diastolic, age)}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {readings.length > 10 && (
                <p className="text-xs text-muted-foreground mt-3">
                  Showing 10 of {readings.length}.{" "}
                  <Link href="/history" className="text-primary hover:underline font-medium">View all</Link>
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
