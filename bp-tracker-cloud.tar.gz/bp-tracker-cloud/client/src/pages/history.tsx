import { useState } from "react";
import {
  useListReadings,         getListReadingsQueryKey,
  useDeleteReading,
  useUpdateReading,
  getGetDashboardSummaryQueryKey,
  getGetReadingTrendQueryKey,
  getGetCategoryBreakdownQueryKey,
} from "@/api";
import type { Reading, ActivityLevel, MedicationEntry } from "@/api/generated/api.schemas";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Trash2, Heart, Calendar, Activity, Pill, Pencil, Loader2 } from "lucide-react";
import { getCategoryName, getCategoryStyles, getSystolicColor, formatDate, formatTime } from "@/lib/bp-utils";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { useAge } from "@/lib/age-context";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader,
  AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Link } from "wouter";
import { DateRangeDownload } from "@/components/date-range-download";

const ACTIVITY_OPTIONS: { value: ActivityLevel; label: string }[] = [
  { value: "resting",  label: "Resting" },
  { value: "light",    label: "Light activity" },
  { value: "moderate", label: "Moderate activity" },
  { value: "exercise", label: "Exercised" },
];

function toLocalDateTimeInput(isoString: string): string {
  const d = new Date(isoString);
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 16);
}

export default function History() {
  const { data: readings, isLoading } = useListReadings(
    { limit: 100 },
    { query: { queryKey: getListReadingsQueryKey({ limit: 100 }) } },
  );
  const deleteReading = useDeleteReading();
  const updateReading = useUpdateReading();
  const queryClient   = useQueryClient();
  const { toast }     = useToast();
  const { auth }      = useAuth();
  const { age }       = useAge();

  // ── Edit state ──────────────────────────────────────────────────────────
  const [editReading,    setEditReading]    = useState<Reading | null>(null);
  const [editSystolic,   setEditSystolic]   = useState("");
  const [editDiastolic,  setEditDiastolic]  = useState("");
  const [editPulse,      setEditPulse]      = useState("");
  const [editNotes,      setEditNotes]      = useState("");
  const [editRecordedAt, setEditRecordedAt] = useState("");
  const [editActivity,   setEditActivity]   = useState<ActivityLevel | null>(null);

  const openEdit = (r: Reading) => {
    setEditReading(r);
    setEditSystolic(String(r.systolic));
    setEditDiastolic(String(r.diastolic));
    setEditPulse(r.pulse ? String(r.pulse) : "");
    setEditNotes(r.notes ?? "");
    setEditRecordedAt(toLocalDateTimeInput(r.recordedAt));
    setEditActivity((r.activityLevel as ActivityLevel) ?? null);
  };

  const closeEdit = () => setEditReading(null);

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: getListReadingsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetReadingTrendQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetCategoryBreakdownQueryKey() });
  };

  const handleSaveEdit = () => {
    if (!editReading) return;
    const sys = parseInt(editSystolic);
    const dia = parseInt(editDiastolic);
    if (!sys || !dia) return;

    updateReading.mutate({
      id: editReading.id,
      data: {
        systolic:      sys,
        diastolic:     dia,
        pulse:         editPulse ? parseInt(editPulse) : null,
        notes:         editNotes || null,
        recordedAt:    new Date(editRecordedAt).toISOString(),
        activityLevel: editActivity,
        medicationsTaken: editReading.medicationsTaken as MedicationEntry[] | null,
      },
    }, {
      onSuccess: () => {
        toast({ title: "Reading updated" });
        invalidateAll();
        closeEdit();
      },
      onError: () => {
        toast({ title: "Error", description: "Could not update reading.", variant: "destructive" });
      },
    });
  };

  const handleDelete = (id: number) => {
    deleteReading.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Reading deleted", description: "The reading has been removed from your history." });
        invalidateAll();
      },
      onError: () => {
        toast({ title: "Error", description: "Could not delete reading.", variant: "destructive" });
      },
    });
  };

  // preview category while editing
  const editSys = parseInt(editSystolic);
  const editDia = parseInt(editDiastolic);
  const editHasValid = editSys > 0 && editDia > 0;

  return (
    <div className="space-y-4 animate-in fade-in duration-500 pb-12">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-foreground">History</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Your complete record of blood pressure readings.</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {readings && readings.length > 0 && <DateRangeDownload />}
          <Link
            href="/log"
            className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-xl text-sm font-semibold shadow-sm transition-all hover:-translate-y-0.5 hidden sm:block"
          >
            Add Reading
          </Link>
        </div>
      </div>

      <div className="space-y-2">
        {isLoading ? (
          Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-2xl" />)
        ) : readings && readings.length > 0 ? (
          readings.map((reading, i) => (
            <Card
              key={reading.id}
              className="border shadow-sm hover-elevate group animate-in slide-in-from-bottom-1"
              style={{ animationDelay: `${i * 40}ms`, animationFillMode: "both" }}
            >
              <CardContent className="p-0">
                <div className="flex items-center justify-between p-4 sm:p-5 gap-4">

                  {/* BP numbers */}
                  <div className="flex items-center gap-5">
                    <div className="flex items-baseline gap-0.5">
                      <span className={`bp-number text-3xl font-medium ${getSystolicColor(reading.systolic, reading.diastolic, age)}`}>
                        {reading.systolic}
                      </span>
                      <span className="bp-number text-xl text-border mx-1 font-light">/</span>
                      <span className="bp-number text-2xl font-medium text-foreground/60">
                        {reading.diastolic}
                      </span>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge
                          variant="outline"
                          className={`px-2.5 py-0.5 rounded-full border text-xs font-semibold ${getCategoryStyles(reading.systolic, reading.diastolic, age)}`}
                        >
                          {getCategoryName(reading.systolic, reading.diastolic, age)}
                        </Badge>
                        {reading.pulse && (
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Heart className="w-3 h-3 text-primary/60" />
                            {reading.pulse} bpm
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        {formatDate(reading.recordedAt)} at {formatTime(reading.recordedAt)}
                      </div>
                      {(reading.activityLevel || (reading.medicationsTaken && (reading.medicationsTaken as MedicationEntry[]).length > 0)) && (
                        <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                          {reading.activityLevel && (
                            <span className="flex items-center gap-1 text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                              <Activity className="w-2.5 h-2.5" />
                              {reading.activityLevel === "resting" ? "Resting" :
                               reading.activityLevel === "light"   ? "Light activity" :
                               reading.activityLevel === "moderate"? "Moderate activity" : "Exercised"}
                            </span>
                          )}
                          {reading.medicationsTaken && (reading.medicationsTaken as MedicationEntry[]).length > 0 && (
                            <span
                              className="flex items-center gap-1 text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full"
                              title={(reading.medicationsTaken as MedicationEntry[]).map(m => m.dosage ? `${m.name} ${m.dosage}` : m.name).join(", ")}
                            >
                              <Pill className="w-2.5 h-2.5" />
                              {(reading.medicationsTaken as MedicationEntry[]).length === 1
                                ? (reading.medicationsTaken as MedicationEntry[])[0].name
                                : `${(reading.medicationsTaken as MedicationEntry[]).length} medications`}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Notes + actions */}
                  <div className="flex items-center gap-2 ml-auto">
                    {reading.notes && (
                      <p className="text-xs text-muted-foreground italic line-clamp-1 max-w-[160px] hidden sm:block">
                        "{reading.notes}"
                      </p>
                    )}

                    {/* Edit button */}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => openEdit(reading)}
                      title="Edit reading"
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>

                    {/* Delete button */}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete reading?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This reading will be permanently removed. This cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDelete(reading.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>

                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="py-16 text-center border border-dashed border-border rounded-2xl bg-card/50">
            <p className="text-muted-foreground mb-4">No readings logged yet.</p>
            <Link href="/log" className="text-primary hover:underline font-semibold text-sm">
              Log your first reading
            </Link>
          </div>
        )}
      </div>

      {/* ── Edit dialog ── */}
      <Dialog open={editReading !== null} onOpenChange={(o) => { if (!o) closeEdit(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Reading</DialogTitle>
            <DialogDescription>
              Update the values for this reading.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* Category preview */}
            <div className="flex justify-center">
              {editHasValid ? (
                <Badge variant="outline" className={`px-4 py-1.5 rounded-full border text-sm font-semibold ${getCategoryStyles(editSys, editDia, age)}`}>
                  {getCategoryName(editSys, editDia, age)}
                </Badge>
              ) : (
                <span className="px-4 py-1.5 rounded-full border border-border bg-muted text-muted-foreground text-sm">
                  Enter values to preview
                </span>
              )}
            </div>

            {/* BP inputs */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Systolic</Label>
                <Input
                  type="number" min="50" max="300"
                  value={editSystolic}
                  onChange={(e) => setEditSystolic(e.target.value)}
                  className={`bp-number text-4xl h-20 text-center font-medium bg-muted/50 ${editHasValid ? getSystolicColor(editSys, editDia, age) : ""}`}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Diastolic</Label>
                <Input
                  type="number" min="30" max="200"
                  value={editDiastolic}
                  onChange={(e) => setEditDiastolic(e.target.value)}
                  className="bp-number text-4xl h-20 text-center font-medium text-foreground/70 bg-muted/50"
                />
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Pulse (optional)</Label>
                <Input
                  type="number" min="30" max="250"
                  value={editPulse}
                  onChange={(e) => setEditPulse(e.target.value)}
                  placeholder="bpm"
                  className="bg-muted/50"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Date &amp; Time</Label>
                <Input
                  type="datetime-local"
                  value={editRecordedAt}
                  onChange={(e) => setEditRecordedAt(e.target.value)}
                  className="bg-muted/50"
                />
              </div>
            </div>

            {/* Activity level */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Activity Level</Label>
              <div className="grid grid-cols-2 gap-2">
                {ACTIVITY_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setEditActivity(editActivity === opt.value ? null : opt.value)}
                    className={`p-2.5 rounded-xl border text-sm font-medium text-left transition-colors ${
                      editActivity === opt.value
                        ? "bg-primary/10 border-primary/30 text-primary"
                        : "bg-muted/40 border-border/60 text-muted-foreground hover:bg-muted"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Notes</Label>
              <Textarea
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                placeholder="How were you feeling?"
                className="resize-none h-16 bg-muted/50"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={closeEdit} disabled={updateReading.isPending}>Cancel</Button>
            <Button
              onClick={handleSaveEdit}
              disabled={!editHasValid || updateReading.isPending}
            >
              {updateReading.isPending && <Loader2 className="mr-2 h-3 w-3 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
