import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  useCreateReading,
  getGetDashboardSummaryQueryKey,
  getListReadingsQueryKey,
  getGetReadingTrendQueryKey,
  getGetCategoryBreakdownQueryKey,
} from "@/api";
import type { ActivityLevel, MedicationEntry } from "@/api/generated/api.schemas";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { useAge } from "@/lib/age-context";
import { Loader2, Pill, Activity, ChevronDown, ChevronUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { getCategoryName, getCategoryStyles, getSystolicColor } from "@/lib/bp-utils";
import type { MedicationFull } from "./medications";
import { FREQUENCY_LABELS, TIME_LABELS } from "./medications";
import { Link } from "wouter";

const ACTIVITY_OPTIONS: { value: ActivityLevel; label: string; desc: string }[] = [
  { value: "resting",  label: "Resting",  desc: "Sitting or lying down, at rest" },
  { value: "light",    label: "Light",    desc: "Light activity today" },
  { value: "moderate", label: "Moderate", desc: "Moderate activity today" },
  { value: "exercise", label: "Exercised", desc: "Exercised in the last few hours" },
];

export default function Log() {
  const [, setLocation] = useLocation();
  const { toast }       = useToast();
  const { auth }        = useAuth();
  const { age }         = useAge();
  const queryClient     = useQueryClient();
  const createReading   = useCreateReading();

  // Core reading fields
  const [systolic,   setSystolic]   = useState("");
  const [diastolic,  setDiastolic]  = useState("");
  const [pulse,      setPulse]      = useState("");
  const [notes,      setNotes]      = useState("");
  const [recordedAt, setRecordedAt] = useState(() => {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    return now.toISOString().slice(0, 16);
  });

  // Context fields
  const [activityLevel,    setActivityLevel]    = useState<ActivityLevel | null>(null);
  const [medicationTaken,  setMedicationTaken]  = useState<boolean | null>(null);
  const [selectedMedIds,   setSelectedMedIds]   = useState<Set<number>>(new Set());
  const [freeTextMed,      setFreeTextMed]      = useState("");
  const [showContext,      setShowContext]       = useState(false);

  // Saved medications
  const [savedMeds,   setSavedMeds]   = useState<MedicationFull[]>([]);
  const [loadingMeds, setLoadingMeds] = useState(false);

  useEffect(() => {
    if (!showContext) return;
    setLoadingMeds(true);
    fetch("/api/medications", { headers: { Authorization: `Bearer ${auth.token}` } })
      .then((r) => r.json())
      .then((data: MedicationFull[]) => setSavedMeds(data))
      .catch(() => {})
      .finally(() => setLoadingMeds(false));
  }, [showContext, auth.token]);

  const sysNum   = parseInt(systolic);
  const diaNum   = parseInt(diastolic);
  const hasValid = sysNum > 0 && diaNum > 0;

  const catStyles = hasValid ? getCategoryStyles(sysNum, diaNum, age) : "";
  const catName   = hasValid ? getCategoryName(sysNum, diaNum, age)   : "Enter values to preview…";
  const sysColor  = hasValid ? getSystolicColor(sysNum, diaNum, age)  : "text-muted-foreground";

  const toggleMed = (id: number) => {
    setSelectedMedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const buildMedicationsTaken = (): MedicationEntry[] | null => {
    if (!medicationTaken) return null;
    const entries: MedicationEntry[] = [];

    // From saved medications
    for (const med of savedMeds) {
      if (selectedMedIds.has(med.id)) {
        entries.push({ name: med.name, dosage: med.dosage ?? null });
      }
    }

    // Free text (one-off / OTC medication)
    const ft = freeTextMed.trim();
    if (ft) entries.push({ name: ft, dosage: null });

    return entries.length > 0 ? entries : [];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasValid) return;

    createReading.mutate({
      data: {
        systolic: sysNum,
        diastolic: diaNum,
        pulse: pulse ? parseInt(pulse) : null,
        notes: notes || null,
        recordedAt: new Date(recordedAt).toISOString(),
        activityLevel: activityLevel,
        medicationsTaken: buildMedicationsTaken(),
      },
    }, {
      onSuccess: () => {
        toast({ title: "Reading logged", description: "Your blood pressure reading has been saved." });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListReadingsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetReadingTrendQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCategoryBreakdownQueryKey() });
        setLocation("/");
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to save reading. Please try again.", variant: "destructive" });
      },
    });
  };

  return (
    <div className="max-w-xl mx-auto animate-in fade-in duration-500 py-4 pb-12">
      <div className="mb-6">
        <h2 className="text-2xl font-bold tracking-tight text-foreground mb-1">Log Reading</h2>
        <p className="text-sm text-muted-foreground">Record your blood pressure to keep your history up to date.</p>
      </div>

      <Card className="border shadow-sm">
        <CardContent className="pt-6 px-6 pb-6">
          <form onSubmit={handleSubmit} className="space-y-6">

            {/* ── Category preview pill ── */}
            <div className="flex justify-center">
              {hasValid ? (
                <Badge variant="outline" className={`px-4 py-1.5 rounded-full border text-sm font-semibold ${catStyles}`}>
                  <span className="pulse-dot mr-2" style={{ width: "6px", height: "6px" }} />
                  {catName}
                </Badge>
              ) : (
                <span className="px-4 py-1.5 rounded-full border border-border bg-muted text-muted-foreground text-sm">
                  {catName}
                </span>
              )}
            </div>

            {/* ── BP numbers ── */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Systolic</Label>
                <Input
                  type="number" min="50" max="300" required
                  value={systolic} onChange={(e) => setSystolic(e.target.value)}
                  placeholder="120"
                  className={`bp-number text-5xl h-24 text-center font-medium bg-muted/50 border-border/60 hover:border-border focus:bg-background transition-colors ${sysColor}`}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Diastolic</Label>
                <Input
                  type="number" min="30" max="200" required
                  value={diastolic} onChange={(e) => setDiastolic(e.target.value)}
                  placeholder="80"
                  className="bp-number text-5xl h-24 text-center font-medium text-foreground/70 bg-muted/50 border-border/60 hover:border-border focus:bg-background transition-colors"
                />
              </div>
            </div>

            {/* ── Pulse + DateTime ── */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-border/60">
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Pulse (optional)</Label>
                <Input
                  type="number" min="30" max="250"
                  value={pulse} onChange={(e) => setPulse(e.target.value)}
                  placeholder="70 bpm"
                  className="bg-muted/50 border-border/60"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Date &amp; Time</Label>
                <Input
                  type="datetime-local" required
                  value={recordedAt} onChange={(e) => setRecordedAt(e.target.value)}
                  className="bg-muted/50 border-border/60"
                />
              </div>
            </div>

            {/* ── Notes ── */}
            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Notes (optional)</Label>
              <Textarea
                placeholder="How are you feeling?"
                className="resize-none h-16 bg-muted/50 border-border/60"
                value={notes} onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            <Separator />

            {/* ── Context section toggle ── */}
            <button
              type="button"
              onClick={() => setShowContext(!showContext)}
              className="w-full flex items-center justify-between text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors -mt-2"
            >
              <span className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" />
                Context &amp; Medications
                {(activityLevel || medicationTaken !== null) && (
                  <span className="w-2 h-2 rounded-full bg-primary inline-block" title="Context recorded" />
                )}
              </span>
              {showContext ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showContext && (
              <div className="space-y-6 animate-in slide-in-from-top-1 duration-200">

                {/* Activity level */}
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Activity Level</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {ACTIVITY_OPTIONS.map((opt) => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setActivityLevel(activityLevel === opt.value ? null : opt.value)}
                        className={`p-3 rounded-xl border text-left transition-colors ${
                          activityLevel === opt.value
                            ? "bg-primary/10 border-primary/30 text-primary"
                            : "bg-muted/40 border-border/60 text-muted-foreground hover:bg-muted"
                        }`}
                      >
                        <p className="text-sm font-semibold">{opt.label}</p>
                        <p className="text-xs opacity-70 mt-0.5">{opt.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Medication taken */}
                <div className="space-y-3">
                  <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Medication Taken?</Label>
                  <div className="flex gap-2">
                    {[{ value: true, label: "Yes" }, { value: false, label: "No" }].map((opt) => (
                      <button
                        key={String(opt.value)}
                        type="button"
                        onClick={() => {
                          setMedicationTaken(medicationTaken === opt.value ? null : opt.value);
                          if (!opt.value) { setSelectedMedIds(new Set()); setFreeTextMed(""); }
                        }}
                        className={`flex-1 py-2.5 rounded-xl border text-sm font-semibold transition-colors ${
                          medicationTaken === opt.value
                            ? "bg-primary/10 border-primary/30 text-primary"
                            : "bg-muted/40 border-border/60 text-muted-foreground hover:bg-muted"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>

                  {/* Medication picker — only shown when Yes selected */}
                  {medicationTaken === true && (
                    <div className="space-y-3 animate-in slide-in-from-top-1 duration-200 pt-1">
                      {loadingMeds ? (
                        <p className="text-xs text-muted-foreground">Loading medications…</p>
                      ) : savedMeds.length > 0 ? (
                        <>
                          <p className="text-xs text-muted-foreground">Select which medications were taken:</p>
                          <div className="space-y-1.5">
                            {savedMeds.map((med) => (
                              <button
                                key={med.id}
                                type="button"
                                onClick={() => toggleMed(med.id)}
                                className={`w-full flex items-center gap-3 p-2.5 rounded-xl border text-left transition-colors ${
                                  selectedMedIds.has(med.id)
                                    ? "bg-primary/10 border-primary/30"
                                    : "bg-muted/40 border-border/60 hover:bg-muted"
                                }`}
                              >
                                <div className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 transition-colors ${
                                  selectedMedIds.has(med.id) ? "bg-primary border-primary" : "border-border"
                                }`}>
                                  {selectedMedIds.has(med.id) && (
                                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-baseline gap-1.5 flex-wrap">
                                    <span className="text-sm font-medium text-foreground">{med.name}</span>
                                    {med.dosage && <span className="text-xs text-muted-foreground">{med.dosage}</span>}
                                  </div>
                                  {(med.frequency || (med.timeOfDay && med.timeOfDay !== "any_time")) && (
                                    <p className="text-xs text-muted-foreground/70 mt-0.5">
                                      {[
                                        med.frequency ? FREQUENCY_LABELS[med.frequency] : null,
                                        med.timeOfDay && med.timeOfDay !== "any_time" ? TIME_LABELS[med.timeOfDay] : null,
                                      ].filter(Boolean).join(" · ")}
                                    </p>
                                  )}
                                </div>
                              </button>
                            ))}
                          </div>
                        </>
                      ) : (
                        <p className="text-xs text-muted-foreground">
                          No saved medications.{" "}
                          <Link href="/medications" className="text-primary hover:underline font-medium">
                            Add your medications
                          </Link>{" "}
                          to select them here.
                        </p>
                      )}

                      {/* Free text field — always shown when Yes, labelled differently based on whether saved meds exist */}
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-muted-foreground">
                          {savedMeds.length > 0 ? "Other / one-off medication (optional)" : "Medication taken"}
                        </Label>
                        <div className="relative">
                          <Pill className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                          <Input
                            value={freeTextMed}
                            onChange={(e) => setFreeTextMed(e.target.value)}
                            placeholder={savedMeds.length > 0 ? "e.g. Paracetamol 500mg" : "e.g. Amlodipine 5mg, Aspirin 75mg"}
                            className="pl-9 bg-muted/50 border-border/60 focus:bg-background text-sm"
                            maxLength={200}
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            <Button
              type="submit"
              size="lg"
              className="w-full font-semibold tracking-tight"
              disabled={!hasValid || createReading.isPending}
            >
              {createReading.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Reading
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
