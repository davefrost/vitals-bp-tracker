import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { Loader2, Pill, Pencil, Trash2, X, Check, Plus, Clock, Calendar } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader,
  AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

// ── Types ──────────────────────────────────────────────────────────────────
export interface MedicationFull {
  id: number;
  name: string;
  dosage: string | null;
  frequency: string | null;
  timeOfDay: string | null;
  startDate: string | null;
  notes: string | null;
  active: boolean;
  createdAt: string;
}

// Keep backward-compatible alias for log.tsx
export type Medication = MedicationFull;

interface MedFormState {
  name: string;
  dosage: string;
  frequency: string;
  timeOfDay: string;
  startDate: string;
  notes: string;
}

const EMPTY_FORM: MedFormState = {
  name: "", dosage: "", frequency: "", timeOfDay: "", startDate: "", notes: "",
};

// ── Label helpers ──────────────────────────────────────────────────────────
export const FREQUENCY_LABELS: Record<string, string> = {
  once_daily:      "Once daily",
  twice_daily:     "Twice daily",
  three_daily:     "Three times daily",
  four_daily:      "Four times daily",
  every_other_day: "Every other day",
  weekly:          "Weekly",
  as_needed:       "As needed (PRN)",
};

export const TIME_LABELS: Record<string, string> = {
  any_time:     "Any time",
  morning:      "Morning",
  midday:       "Midday",
  evening:      "Evening",
  night:        "Night / Bedtime",
  with_food:    "With food",
  before_meals: "Before meals",
  after_meals:  "After meals",
};

// ── Medication summary line ────────────────────────────────────────────────
function medSummary(med: MedicationFull): string {
  const parts: string[] = [];
  if (med.dosage)    parts.push(med.dosage);
  if (med.frequency) parts.push(FREQUENCY_LABELS[med.frequency] ?? med.frequency);
  if (med.timeOfDay && med.timeOfDay !== "any_time")
    parts.push(TIME_LABELS[med.timeOfDay] ?? med.timeOfDay);
  return parts.join(" · ");
}

// ── Form component (used for both add and edit) ────────────────────────────
function MedForm({
  initial, onSave, onCancel, saving,
}: {
  initial: MedFormState;
  onSave: (form: MedFormState) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [form, setForm] = useState<MedFormState>(initial);
  const set = (k: keyof MedFormState) => (v: string) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Medication Name <span className="text-destructive">*</span>
          </Label>
          <Input
            value={form.name}
            onChange={(e) => set("name")(e.target.value)}
            placeholder="e.g. Lisinopril"
            maxLength={100}
            autoFocus
            className="bg-muted/50 border-border/60 focus:bg-background"
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Dosage <span className="text-destructive">*</span>
          </Label>
          <Input
            value={form.dosage}
            onChange={(e) => set("dosage")(e.target.value)}
            placeholder="e.g. 10mg"
            maxLength={50}
            className="bg-muted/50 border-border/60 focus:bg-background"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Frequency</Label>
          <Select value={form.frequency} onValueChange={set("frequency")}>
            <SelectTrigger className="bg-muted/50 border-border/60">
              <SelectValue placeholder="Select frequency" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(FREQUENCY_LABELS).map(([v, label]) => (
                <SelectItem key={v} value={v}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Time of Day</Label>
          <Select value={form.timeOfDay} onValueChange={set("timeOfDay")}>
            <SelectTrigger className="bg-muted/50 border-border/60">
              <SelectValue placeholder="Select time" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(TIME_LABELS).map(([v, label]) => (
                <SelectItem key={v} value={v}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Start Date</Label>
        <Input
          type="date"
          value={form.startDate}
          onChange={(e) => set("startDate")(e.target.value)}
          className="bg-muted/50 border-border/60 focus:bg-background"
        />
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Notes (optional)</Label>
        <Textarea
          value={form.notes}
          onChange={(e) => set("notes")(e.target.value)}
          placeholder="e.g. Take with food, avoid grapefruit…"
          className="resize-none h-20 bg-muted/50 border-border/60"
          maxLength={500}
        />
      </div>

      <div className="flex justify-end gap-2 pt-1">
        <Button type="button" variant="outline" onClick={onCancel} disabled={saving}>Cancel</Button>
        <Button type="button" onClick={() => onSave(form)} disabled={saving || !form.name.trim()}>
          {saving && <Loader2 className="mr-2 h-3 w-3 animate-spin" />}
          Save
        </Button>
      </div>
    </div>
  );
}

// ── Main page ──────────────────────────────────────────────────────────────
export default function Medications() {
  const { auth }   = useAuth();
  const { toast }  = useToast();

  const [medications, setMedications] = useState<MedicationFull[]>([]);
  const [loading, setLoading]         = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [addSaving, setAddSaving]         = useState(false);
  const [editId, setEditId]               = useState<number | null>(null);
  const [editSaving, setEditSaving]       = useState(false);

  const headers = { Authorization: `Bearer ${auth.token}` };
  const jsonHeaders = { ...headers, "Content-Type": "application/json" };

  const fetchMeds = () => {
    fetch("/api/medications", { headers })
      .then((r) => r.json())
      .then((d: MedicationFull[]) => { setMedications(d); setLoading(false); })
      .catch(() => { toast({ title: "Error loading medications", variant: "destructive" }); setLoading(false); });
  };

  useEffect(() => { fetchMeds(); }, []);

  const handleAdd = async (form: MedFormState) => {
    setAddSaving(true);
    try {
      const res = await fetch("/api/medications", {
        method: "POST",
        headers: jsonHeaders,
        body: JSON.stringify({
          name:      form.name.trim(),
          dosage:    form.dosage.trim()    || null,
          frequency: form.frequency        || null,
          timeOfDay: form.timeOfDay        || null,
          startDate: form.startDate        || null,
          notes:     form.notes.trim()     || null,
        }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      setShowAddDialog(false);
      fetchMeds();
      toast({ title: "Medication added" });
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed", variant: "destructive" });
    } finally {
      setAddSaving(false);
    }
  };

  const handleEdit = async (id: number, form: MedFormState) => {
    setEditSaving(true);
    try {
      const res = await fetch(`/api/medications/${id}`, {
        method: "PATCH",
        headers: jsonHeaders,
        body: JSON.stringify({
          name:      form.name.trim(),
          dosage:    form.dosage.trim()    || null,
          frequency: form.frequency        || null,
          timeOfDay: form.timeOfDay        || null,
          startDate: form.startDate        || null,
          notes:     form.notes.trim()     || null,
        }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      setEditId(null);
      fetchMeds();
      toast({ title: "Medication updated" });
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed", variant: "destructive" });
    } finally {
      setEditSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      const res = await fetch(`/api/medications/${id}`, { method: "DELETE", headers });
      if (!res.ok) throw new Error((await res.json()).error);
      fetchMeds();
      toast({ title: "Medication removed" });
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Failed", variant: "destructive" });
    }
  };

  const editingMed = editId !== null ? medications.find((m) => m.id === editId) : null;
  const editInitial: MedFormState = editingMed ? {
    name:      editingMed.name,
    dosage:    editingMed.dosage    ?? "",
    frequency: editingMed.frequency ?? "",
    timeOfDay: editingMed.timeOfDay ?? "",
    startDate: editingMed.startDate ?? "",
    notes:     editingMed.notes     ?? "",
  } : EMPTY_FORM;

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-in fade-in duration-500 pb-12">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-foreground">My Medications</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Add your regular medications. When logging a reading, record which were taken at the time.
          </p>
        </div>
        <Button size="sm" onClick={() => setShowAddDialog(true)} className="gap-2 shrink-0">
          <Plus className="w-4 h-4" /> Add Medication
        </Button>
      </div>

      {/* ── Medication list ── */}
      <Card className="border shadow-sm">
        <CardHeader className="pb-2 pt-5 px-6">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Pill className="w-4 h-4 text-primary" /> Current Medications ({medications.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="px-6 pb-6">
          {loading ? (
            <div className="space-y-3">
              {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
            </div>
          ) : medications.length === 0 ? (
            <div className="text-center py-8">
              <Pill className="w-8 h-8 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No medications added yet.</p>
              <button
                onClick={() => setShowAddDialog(true)}
                className="text-sm text-primary hover:underline font-medium mt-1"
              >
                Add your first medication
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {medications.map((med) => (
                <div
                  key={med.id}
                  className="flex items-start justify-between p-4 rounded-xl border border-border bg-muted/30 hover:bg-muted/50 transition-colors group"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Pill className="w-4 h-4 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-foreground">{med.name}</p>
                      {medSummary(med) && (
                        <p className="text-xs text-muted-foreground mt-0.5">{medSummary(med)}</p>
                      )}
                      <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                        {med.startDate && (
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Calendar className="w-3 h-3" />
                            Since {new Date(med.startDate).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                          </span>
                        )}
                        {med.timeOfDay && med.timeOfDay !== "any_time" && (
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            {TIME_LABELS[med.timeOfDay] ?? med.timeOfDay}
                          </span>
                        )}
                      </div>
                      {med.notes && (
                        <p className="text-xs text-muted-foreground/70 italic mt-1">"{med.notes}"</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 ml-2 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                    <Button
                      variant="ghost" size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-foreground"
                      onClick={() => setEditId(med.id)}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Remove {med.name}?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This removes it from your medications list. Past readings that recorded this medication are not affected.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDelete(med.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            Remove
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Add dialog ── */}
      <Dialog open={showAddDialog} onOpenChange={(o) => { if (!o) setShowAddDialog(false); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Medication</DialogTitle>
            <DialogDescription>Add a regular medication to your list.</DialogDescription>
          </DialogHeader>
          <MedForm
            initial={EMPTY_FORM}
            onSave={handleAdd}
            onCancel={() => setShowAddDialog(false)}
            saving={addSaving}
          />
        </DialogContent>
      </Dialog>

      {/* ── Edit dialog ── */}
      <Dialog open={editId !== null} onOpenChange={(o) => { if (!o) setEditId(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Medication</DialogTitle>
            <DialogDescription>Update medication details.</DialogDescription>
          </DialogHeader>
          {editId !== null && (
            <MedForm
              initial={editInitial}
              onSave={(form) => handleEdit(editId, form)}
              onCancel={() => setEditId(null)}
              saving={editSaving}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
