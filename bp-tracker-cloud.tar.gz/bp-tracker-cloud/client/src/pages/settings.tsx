import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { Loader2, Eye, EyeOff, User, Lock, Palette } from "lucide-react";
import { useAge } from "@/lib/age-context";
import { useTheme } from "@/lib/theme-context";

interface UserSettings {
  username: string;
  displayName: string | null;
  dateOfBirth: string | null;
  theme: "light" | "dark" | "system";
  isAdmin: boolean;
}

export default function Settings() {
  const { auth } = useAuth();
  const { toast } = useToast();

  const { setDateOfBirth: setContextDob } = useAge();
  const { setTheme: applyTheme } = useTheme();
  const [settings, setSettings]       = useState<UserSettings | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [theme, setTheme]             = useState<"light" | "dark" | "system">("light");
  const [savingProfile, setSavingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword]         = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrent, setShowCurrent]         = useState(false);
  const [showNew, setShowNew]                 = useState(false);
  const [savingPassword, setSavingPassword]   = useState(false);

  useEffect(() => {
    fetch("/api/account/settings", {
      headers: { Authorization: `Bearer ${auth.token}` },
    })
      .then((r) => r.json())
      .then((data: UserSettings) => {
        setSettings(data);
        setDisplayName(data.displayName ?? "");
        setDateOfBirth(data.dateOfBirth ?? "");
        setTheme(data.theme);
      })
      .catch(() => toast({ title: "Error", description: "Could not load settings.", variant: "destructive" }));
  }, [auth.token]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const res = await fetch("/api/account/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.token}` },
        body: JSON.stringify({ displayName: displayName || null, dateOfBirth: dateOfBirth || null, theme }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      const updated: UserSettings = await res.json();
      setSettings(updated);
      setContextDob(updated.dateOfBirth ?? null);
      toast({ title: "Profile updated" });
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Could not save.", variant: "destructive" });
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast({ title: "Passwords don't match", variant: "destructive" });
      return;
    }
    if (newPassword.length < 6) {
      toast({ title: "Password too short", description: "Must be at least 6 characters.", variant: "destructive" });
      return;
    }
    setSavingPassword(true);
    try {
      const res = await fetch("/api/account/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.token}` },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      toast({ title: "Password changed" });
    } catch (err) {
      toast({ title: "Error", description: err instanceof Error ? err.message : "Could not change password.", variant: "destructive" });
    } finally {
      setSavingPassword(false);
    }
  };

  const themeOptions: { value: "light" | "dark" | "system"; label: string }[] = [
    { value: "light",  label: "Light" },
    { value: "dark",   label: "Dark" },
    { value: "system", label: "System default" },
  ];

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-in fade-in duration-500 pb-12">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-foreground">Settings</h2>
        <p className="text-sm text-muted-foreground mt-0.5">Manage your account preferences.</p>
      </div>

      {/* ── Profile ── */}
      <Card className="border shadow-sm">
        <CardHeader className="pb-2 pt-5 px-6">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <User className="w-4 h-4 text-primary" /> Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="px-6 pb-6">
          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Username
              </Label>
              <Input value={settings?.username ?? auth.username ?? ""} disabled className="bg-muted/50" />
              <p className="text-xs text-muted-foreground">Username cannot be changed.</p>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Display Name (optional)
              </Label>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="How your name appears in reports"
                maxLength={60}
                className="bg-muted/50 border-border/60 focus:bg-background"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Date of Birth (optional)
              </Label>
              <Input
                type="date"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                max={new Date().toISOString().slice(0, 10)}
                min="1900-01-01"
                className="bg-muted/50 border-border/60 focus:bg-background"
              />
              <p className="text-xs text-muted-foreground">
                Used to apply age-appropriate blood pressure guidelines. Adults aged 80+ have different NHS target thresholds.
              </p>
            </div>

            <Button type="submit" size="sm" disabled={savingProfile}>
              {savingProfile && <Loader2 className="mr-2 h-3 w-3 animate-spin" />}
              Save Profile
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* ── Appearance ── */}
      <Card className="border shadow-sm">
        <CardHeader className="pb-2 pt-5 px-6">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Palette className="w-4 h-4 text-primary" /> Appearance
          </CardTitle>
        </CardHeader>
        <CardContent className="px-6 pb-6">
          <div className="space-y-3">
            <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Theme
            </Label>
            <div className="grid grid-cols-3 gap-2">
              {themeOptions.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => { setTheme(opt.value); applyTheme(opt.value); }}
                  className={`px-3 py-2.5 rounded-xl border text-sm font-medium transition-colors ${
                    theme === opt.value
                      ? "bg-primary/10 border-primary/30 text-primary"
                      : "bg-muted/40 border-border/60 text-muted-foreground hover:bg-muted"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">Changes apply instantly. Your preference is saved with your profile.</p>
          </div>
        </CardContent>
      </Card>

      {/* ── Password ── */}
      <Card className="border shadow-sm">
        <CardHeader className="pb-2 pt-5 px-6">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Lock className="w-4 h-4 text-primary" /> Change Password
          </CardTitle>
        </CardHeader>
        <CardContent className="px-6 pb-6">
          <form onSubmit={handleChangePassword} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Current Password
              </Label>
              <div className="relative">
                <Input
                  type={showCurrent ? "text" : "password"}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                  className="pr-10 bg-muted/50 border-border/60 focus:bg-background"
                />
                <button type="button" onClick={() => setShowCurrent(!showCurrent)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showCurrent ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Separator />

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                New Password
              </Label>
              <div className="relative">
                <Input
                  type={showNew ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  placeholder="At least 6 characters"
                  className="pr-10 bg-muted/50 border-border/60 focus:bg-background"
                />
                <button type="button" onClick={() => setShowNew(!showNew)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Confirm New Password
              </Label>
              <Input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="bg-muted/50 border-border/60 focus:bg-background"
              />
            </div>

            <Button type="submit" size="sm" disabled={savingPassword || !currentPassword || !newPassword || !confirmPassword}>
              {savingPassword && <Loader2 className="mr-2 h-3 w-3 animate-spin" />}
              Change Password
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
