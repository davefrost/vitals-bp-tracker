import { pgTable, text, serial, timestamp, integer, boolean, date } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const FREQUENCY_OPTIONS = [
  "once_daily",
  "twice_daily",
  "three_daily",
  "four_daily",
  "every_other_day",
  "weekly",
  "as_needed",
] as const;

export const TIME_OF_DAY_OPTIONS = [
  "any_time",
  "morning",
  "midday",
  "evening",
  "night",
  "with_food",
  "before_meals",
  "after_meals",
] as const;

export type MedicationFrequency = typeof FREQUENCY_OPTIONS[number];
export type MedicationTimeOfDay = typeof TIME_OF_DAY_OPTIONS[number];

export const medicationsTable = pgTable("medications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  name: text("name").notNull(),
  dosage: text("dosage"),
  frequency: text("frequency"),
  timeOfDay: text("time_of_day"),
  startDate: date("start_date"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Medication = typeof medicationsTable.$inferSelect;
export type InsertMedication = typeof medicationsTable.$inferInsert;
