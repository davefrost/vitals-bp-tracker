import { pgTable, text, serial, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { usersTable } from "./users";

export const ACTIVITY_LEVELS = ["resting", "light", "moderate", "exercise"] as const;
export type ActivityLevel = typeof ACTIVITY_LEVELS[number];

export type MedicationEntry = {
  name: string;
  dosage?: string | null;
};

export const readingsTable = pgTable("readings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => usersTable.id),
  systolic: integer("systolic").notNull(),
  diastolic: integer("diastolic").notNull(),
  pulse: integer("pulse"),
  notes: text("notes"),
  activityLevel: text("activity_level"),
  medicationsTaken: jsonb("medications_taken").$type<MedicationEntry[]>(),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertReadingSchema = createInsertSchema(readingsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertReading = z.infer<typeof insertReadingSchema>;
export type Reading = typeof readingsTable.$inferSelect;
