/**
 * Blood pressure classification utility.
 *
 * Thresholds follow NHS/NICE and British Heart Foundation guidelines:
 * - Under 80: standard ACC/AHA / NICE categories (Normal < 120/80 … Hypertensive Crisis > 180/120)
 * - 80 and over: NICE NG136 / BHF age-adjusted target — readings up to 149/89 are clinically
 *   acceptable for this age group; the treatment threshold rises to 150/90.
 *   Reference: BHF "For over-80s the ideal BP is under 150/90 mmHg (or 145/85 at home)."
 *   The hypertensive crisis threshold (> 180/120) is unchanged for all ages.
 */

export type BpCategory =
  | "Normal"
  | "Acceptable for Age"
  | "Elevated"
  | "High Stage 1"
  | "High Stage 2"
  | "Hypertensive Crisis";

export function calcAge(dateOfBirth: string | Date | null | undefined): number | null {
  if (!dateOfBirth) return null;
  const dob  = typeof dateOfBirth === "string" ? new Date(dateOfBirth) : dateOfBirth;
  if (isNaN(dob.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

export function getBpCategory(
  systolic: number,
  diastolic: number,
  age?: number | null,
): BpCategory {
  // Hypertensive crisis threshold is unchanged for all ages
  if (systolic > 180 || diastolic > 120) return "Hypertensive Crisis";

  if (age !== null && age !== undefined && age >= 80) {
    // Over-80 thresholds (NICE NG136 / BHF)
    if (systolic >= 150 || diastolic >= 90) return "High Stage 2";
    // 140–149 systolic is "High Stage 1" but clinically the treatment target is 150, so we
    // keep it labelled High Stage 1 to flag it without alarming — advice text explains context
    if (systolic >= 140)                    return "High Stage 1";
    // Readings up to 149/89 that would be Stage 2 under the standard scale are acceptable
    if (systolic >= 130 || diastolic >= 80) return "Acceptable for Age";
    if (systolic >= 120 && diastolic < 80)  return "Elevated";
    return "Normal";
  }

  // Standard thresholds for under-80s
  if (systolic >= 140 || diastolic >= 90)   return "High Stage 2";
  if (systolic >= 130 || diastolic >= 80)   return "High Stage 1";
  if (systolic >= 120 && diastolic < 80)    return "Elevated";
  return "Normal";
}

export function getCategoryColor(category: BpCategory): string {
  switch (category) {
    case "Normal":             return "#16a34a";
    case "Acceptable for Age": return "#0284c7";  // blue — informational, not alarming
    case "Elevated":           return "#ca8a04";
    case "High Stage 1":       return "#c94030";
    case "High Stage 2":       return "#b91c1c";
    case "Hypertensive Crisis":return "#7c3aed";
    default:                   return "#6b7280";
  }
}

export function getAdvice(category: BpCategory, age?: number | null): string {
  const isOver80 = age !== null && age !== undefined && age >= 80;
  switch (category) {
    case "Normal":
      return "Your blood pressure is in the normal range. Keep up the great work!";

    case "Acceptable for Age":
      return "Your reading is within the accepted target range for adults aged 80 and over (under 150/90 mmHg). Your GP may use a personalised target based on your overall health.";

    case "Elevated":
      return isOver80
        ? "Your blood pressure is slightly elevated. For adults over 80, lifestyle changes and discussion with your GP about monitoring are recommended."
        : "Your blood pressure is slightly elevated. Lifestyle changes can help prevent progression to high blood pressure.";

    case "High Stage 1":
      return isOver80
        ? "Your blood pressure is in the Stage 1 range. For adults over 80, NICE guidelines recommend discussing treatment with your GP, particularly if you have other cardiovascular risk factors."
        : "Your blood pressure indicates Stage 1 hypertension. Consider speaking with a healthcare provider about lifestyle changes and monitoring.";

    case "High Stage 2":
      return isOver80
        ? "Your blood pressure is above the recommended target for your age group (150/90 mmHg). Please consult your GP — treatment targets for over-80s are personalised to your overall health and frailty."
        : "Your blood pressure indicates Stage 2 hypertension. Please consult a healthcare provider promptly for evaluation and treatment.";

    case "Hypertensive Crisis":
      return "Your readings indicate a hypertensive crisis. Please seek immediate medical attention.";

    default:
      return "Log more readings to receive personalised health advice.";
  }
}

export function getTips(category: BpCategory, age?: number | null): string[] {
  const isOver80 = age !== null && age !== undefined && age >= 80;

  if (category === "Normal" || category === "Acceptable for Age") return [
    "Maintain regular gentle activity — walking, swimming or cycling as tolerated",
    "Continue eating a balanced, low-sodium diet",
    "Stay well hydrated throughout the day",
    ...(isOver80 ? [
      "Rise slowly from sitting or lying to reduce the risk of dizziness",
      "Have your blood pressure checked at least annually by your GP",
    ] : [
      "Keep stress levels manageable with relaxation techniques",
    ]),
  ];

  if (category === "Elevated" || category === "High Stage 1") return [
    "Reduce sodium intake — aim for less than 6g (one teaspoon) of salt per day",
    ...(isOver80 ? [
      "Take gentle regular exercise as tolerated — discuss suitable activity with your GP",
      "Rise slowly from sitting or lying to reduce the risk of dizziness",
      "Discuss monitoring frequency and any medication adjustments with your GP",
    ] : [
      "Increase aerobic exercise — 30 minutes most days of the week",
      "Limit alcohol consumption and avoid smoking",
      "Maintain a healthy weight — even small reductions can help",
      "Practise stress management: meditation, deep breathing, or yoga",
      "Eat more fruits, vegetables, whole grains, and low-fat dairy (DASH diet)",
    ]),
  ];

  if (category === "High Stage 2") return [
    "Consult your GP promptly — medication review or adjustment may be needed",
    ...(isOver80 ? [
      "Your GP will set a personalised target based on your overall health and frailty",
      "Monitor your blood pressure at home and keep a record to share with your GP",
      "Rise slowly when standing to avoid orthostatic hypotension (dizziness on standing)",
    ] : [
      "Follow a strict low-sodium diet (under 1,500mg per day)",
      "Monitor your blood pressure at home daily",
      "Avoid caffeine and alcohol",
      "Engage in regular, moderate exercise as advised by your doctor",
    ]),
  ];

  if (category === "Hypertensive Crisis") return [
    "Seek emergency medical care immediately",
    "Do not attempt to lower blood pressure rapidly at home",
    "Note your symptoms and current medications for medical staff",
  ];

  return [
    "Log regular readings to track your blood pressure over time",
    "Take readings at the same time each day for consistency",
    "Sit quietly for 5 minutes before taking a reading",
    "Avoid caffeine, exercise, or smoking 30 minutes before measuring",
  ];
}
