import { pool } from "../db/index.js";
import { logger } from "./logger.js";

export async function migrate(): Promise<void> {
  logger.info("Running database migrations...");

  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS readings (
      id SERIAL PRIMARY KEY,
      systolic INTEGER NOT NULL,
      diastolic INTEGER NOT NULL,
      pulse INTEGER,
      notes TEXT,
      recorded_at TIMESTAMPTZ NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS medications (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      name TEXT NOT NULL,
      dosage TEXT,
      frequency TEXT,
      time_of_day TEXT,
      start_date DATE,
      notes TEXT,
      active BOOLEAN NOT NULL DEFAULT true,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  // Add new medication columns for existing installations
  await pool.query('ALTER TABLE medications ADD COLUMN IF NOT EXISTS frequency TEXT');
  await pool.query('ALTER TABLE medications ADD COLUMN IF NOT EXISTS time_of_day TEXT');
  await pool.query('ALTER TABLE medications ADD COLUMN IF NOT EXISTS start_date DATE');
  await pool.query('ALTER TABLE medications ADD COLUMN IF NOT EXISTS notes TEXT');

  // Idempotent column additions — readings
  await pool.query(`ALTER TABLE readings ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id)`);
  await pool.query(`ALTER TABLE readings ADD COLUMN IF NOT EXISTS activity_level TEXT`);
  await pool.query(`ALTER TABLE readings ADD COLUMN IF NOT EXISTS medications_taken JSONB`);

  // Idempotent column additions — users
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS display_name TEXT`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS theme TEXT NOT NULL DEFAULT 'light'`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT false`);
  await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS date_of_birth DATE');

  // First registered user becomes admin automatically if no admin exists
  await pool.query(`
    UPDATE users SET is_admin = true
    WHERE id = (SELECT MIN(id) FROM users)
    AND NOT EXISTS (SELECT 1 FROM users WHERE is_admin = true)
  `);

  logger.info("Database migrations complete");
}
