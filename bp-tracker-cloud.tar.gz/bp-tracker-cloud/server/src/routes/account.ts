import { Router, type IRouter, type Request } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "../db/index.js";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

// GET /account/settings — return current user's settings
router.get("/account/settings", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;

  const [user] = await db
    .select({
      username: usersTable.username,
      displayName: usersTable.displayName,
      dateOfBirth: usersTable.dateOfBirth,
      theme: usersTable.theme,
      isAdmin: usersTable.isAdmin,
    })
    .from(usersTable)
    .where(eq(usersTable.id, userId));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(user);
});

// PATCH /account/settings — update display name and/or theme
router.patch("/account/settings", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const { displayName, dateOfBirth, theme } = req.body as Record<string, unknown>;

  const updates: Partial<typeof usersTable.$inferInsert> = {};

  if (displayName !== undefined) {
    if (typeof displayName !== "string" || displayName.length > 60) {
      res.status(400).json({ error: "Display name must be a string under 60 characters" });
      return;
    }
    updates.displayName = displayName.trim() || null;
  }

  if (dateOfBirth !== undefined) {
    if (dateOfBirth !== null && dateOfBirth !== "") {
      if (typeof dateOfBirth !== "string" || isNaN(Date.parse(dateOfBirth))) {
        res.status(400).json({ error: "Invalid date of birth" });
        return;
      }
      const dob = new Date(dateOfBirth);
      const minDate = new Date("1900-01-01");
      const today   = new Date();
      if (dob < minDate || dob > today) {
        res.status(400).json({ error: "Date of birth must be between 1900 and today" });
        return;
      }
    }
    updates.dateOfBirth = (dateOfBirth === null || dateOfBirth === "") ? null : dateOfBirth as string;
  }

  if (theme !== undefined) {
    if (theme !== "light" && theme !== "dark" && theme !== "system") {
      res.status(400).json({ error: "Theme must be light, dark, or system" });
      return;
    }
    updates.theme = theme;
  }

  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "No valid fields to update" });
    return;
  }

  const [updated] = await db
    .update(usersTable)
    .set(updates)
    .where(eq(usersTable.id, userId))
    .returning({
      username: usersTable.username,
      displayName: usersTable.displayName,
      dateOfBirth: usersTable.dateOfBirth,
      theme: usersTable.theme,
      isAdmin: usersTable.isAdmin,
    });

  res.json(updated);
});

// POST /account/change-password
router.post("/account/change-password", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const { currentPassword, newPassword } = req.body as Record<string, unknown>;

  if (typeof currentPassword !== "string" || typeof newPassword !== "string") {
    res.status(400).json({ error: "currentPassword and newPassword are required" });
    return;
  }

  if (newPassword.length < 6) {
    res.status(400).json({ error: "New password must be at least 6 characters" });
    return;
  }

  if (currentPassword === newPassword) {
    res.status(400).json({ error: "New password must be different from current password" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const valid = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Current password is incorrect" });
    return;
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);
  await db
    .update(usersTable)
    .set({ passwordHash })
    .where(eq(usersTable.id, userId));

  res.json({ message: "Password changed successfully" });
});

export default router;
