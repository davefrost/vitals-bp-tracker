import { Router, type IRouter, type Request } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable, readingsTable } from "../db/index.js";
import { eq, count } from "drizzle-orm";
import { requireAdmin, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

// GET /admin/users — list all users with reading counts
router.get("/admin/users", requireAdmin, async (_req, res): Promise<void> => {
  const users = await db
    .select({
      id: usersTable.id,
      username: usersTable.username,
      displayName: usersTable.displayName,
      isAdmin: usersTable.isAdmin,
      createdAt: usersTable.createdAt,
    })
    .from(usersTable)
    .orderBy(usersTable.createdAt);

  // Attach reading counts
  const counts = await db
    .select({ userId: readingsTable.userId, total: count() })
    .from(readingsTable)
    .groupBy(readingsTable.userId);

  const countMap = new Map(counts.map((c) => [c.userId, Number(c.total)]));

  res.json(users.map((u) => ({ ...u, readingCount: countMap.get(u.id) ?? 0 })));
});

// POST /admin/users/:id/reset-password — admin sets a new password for any user
router.post("/admin/users/:id/reset-password", requireAdmin, async (req: Request, res): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  const adminId  = (req as AuthenticatedRequest).userId;
  const { newPassword } = req.body as Record<string, unknown>;

  if (isNaN(targetId)) {
    res.status(400).json({ error: "Invalid user ID" });
    return;
  }

  if (typeof newPassword !== "string" || newPassword.length < 6) {
    res.status(400).json({ error: "New password must be at least 6 characters" });
    return;
  }

  const [user] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.id, targetId));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);
  await db
    .update(usersTable)
    .set({ passwordHash })
    .where(eq(usersTable.id, targetId));

  res.json({ message: `Password reset for user ${targetId}` });
});

// PATCH /admin/users/:id/toggle-admin — promote or demote a user
router.patch("/admin/users/:id/toggle-admin", requireAdmin, async (req: Request, res): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  const adminId  = (req as AuthenticatedRequest).userId;

  if (isNaN(targetId)) {
    res.status(400).json({ error: "Invalid user ID" });
    return;
  }

  if (targetId === adminId) {
    res.status(400).json({ error: "You cannot change your own admin status" });
    return;
  }

  const [user] = await db
    .select({ id: usersTable.id, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, targetId));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const [updated] = await db
    .update(usersTable)
    .set({ isAdmin: !user.isAdmin })
    .where(eq(usersTable.id, targetId))
    .returning({ id: usersTable.id, username: usersTable.username, isAdmin: usersTable.isAdmin });

  res.json(updated);
});

// DELETE /admin/users/:id — delete a user and all their readings
router.delete("/admin/users/:id", requireAdmin, async (req: Request, res): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  const adminId  = (req as AuthenticatedRequest).userId;

  if (isNaN(targetId)) {
    res.status(400).json({ error: "Invalid user ID" });
    return;
  }

  if (targetId === adminId) {
    res.status(400).json({ error: "You cannot delete your own account via admin panel" });
    return;
  }

  // Delete readings first (FK constraint)
  await db.delete(readingsTable).where(eq(readingsTable.userId, targetId));
  await db.delete(usersTable).where(eq(usersTable.id, targetId));

  res.sendStatus(204);
});

export default router;
