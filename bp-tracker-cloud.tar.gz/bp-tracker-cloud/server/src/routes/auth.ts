import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db, usersTable } from "../db/index.js";
import { eq, count } from "drizzle-orm";

const router: IRouter = Router();

function validateAuthBody(body: unknown): { username: string; password: string } | null {
  if (!body || typeof body !== "object") return null;
  const { username, password } = body as Record<string, unknown>;
  if (typeof username !== "string" || typeof password !== "string") return null;
  if (username.length < 2 || username.length > 50) return null;
  if (!/^[a-zA-Z0-9_.-]+$/.test(username)) return null;
  if (password.length < 6) return null;
  return { username, password };
}

function signToken(user: { id: number; username: string; isAdmin: boolean }): string {
  const secret = process.env.JWT_SECRET!;
  return jwt.sign(
    { sub: user.id, username: user.username, isAdmin: user.isAdmin },
    secret,
    { expiresIn: "30d" },
  );
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const body = validateAuthBody(req.body);
  if (!body) {
    res.status(400).json({ error: "Username must be 2–50 chars (letters, numbers, _ . -) and password at least 6 characters" });
    return;
  }

  const { username, password } = body;

  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.username, username));

  if (existing) {
    res.status(409).json({ error: "Username already taken" });
    return;
  }

  // First user to register automatically becomes admin
  const [{ total }] = await db.select({ total: count() }).from(usersTable);
  const isAdmin = Number(total) === 0;

  const passwordHash = await bcrypt.hash(password, 10);
  const [user] = await db
    .insert(usersTable)
    .values({ username, passwordHash, isAdmin })
    .returning({ id: usersTable.id, username: usersTable.username, isAdmin: usersTable.isAdmin });

  res.status(201).json({ token: signToken(user), id: user.id, username: user.username, isAdmin: user.isAdmin });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const body = validateAuthBody(req.body);
  if (!body) {
    res.status(400).json({ error: "Invalid credentials" });
    return;
  }

  const { username, password } = body;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.username, username));

  if (!user) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  res.json({ token: signToken(user), id: user.id, username: user.username, isAdmin: user.isAdmin });
});

export default router;
