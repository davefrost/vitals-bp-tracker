import { Router, type IRouter, type Request } from "express";
import { desc, eq } from "drizzle-orm";
import { db, readingsTable, usersTable } from "../db/index.js";
import { GetReadingTrendQueryParams } from "../validation/index.js";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";
import {
  getBpCategory, getCategoryColor, getAdvice, getTips, calcAge,
} from "../lib/bp-categories.js";

const router: IRouter = Router();

router.get("/dashboard/summary", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;

  // Fetch user's DOB alongside readings so we can age-adjust categories
  const [user] = await db
    .select({ dateOfBirth: usersTable.dateOfBirth })
    .from(usersTable)
    .where(eq(usersTable.id, userId));

  const age = calcAge(user?.dateOfBirth ?? null);

  const readings = await db
    .select()
    .from(readingsTable)
    .where(eq(readingsTable.userId, userId))
    .orderBy(desc(readingsTable.recordedAt));

  if (readings.length === 0) {
    res.json({
      totalReadings: 0, avgSystolic: null, avgDiastolic: null, avgPulse: null,
      latestReading: null, currentCategory: null, advice: null,
      tips: getTips("Normal", age), lastReadingDaysAgo: null,
      userAge: age,
    });
    return;
  }

  const totalReadings  = readings.length;
  const avgSystolic    = readings.reduce((s, r) => s + r.systolic,  0) / totalReadings;
  const avgDiastolic   = readings.reduce((s, r) => s + r.diastolic, 0) / totalReadings;
  const pulseReadings  = readings.filter((r) => r.pulse !== null);
  const avgPulse       = pulseReadings.length > 0
    ? pulseReadings.reduce((s, r) => s + (r.pulse ?? 0), 0) / pulseReadings.length
    : null;

  const latestReading  = readings[0];
  const currentCategory = getBpCategory(latestReading.systolic, latestReading.diastolic, age);
  const lastReadingDaysAgo = Math.floor(
    (Date.now() - new Date(latestReading.recordedAt).getTime()) / (1000 * 60 * 60 * 24),
  );

  res.json({
    totalReadings,
    avgSystolic:  Math.round(avgSystolic  * 10) / 10,
    avgDiastolic: Math.round(avgDiastolic * 10) / 10,
    avgPulse:     avgPulse !== null ? Math.round(avgPulse * 10) / 10 : null,
    latestReading,
    currentCategory,
    advice:           getAdvice(currentCategory, age),
    tips:             getTips(currentCategory, age),
    lastReadingDaysAgo,
    userAge: age,
  });
});

router.get("/dashboard/trend", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const query  = GetReadingTrendQueryParams.safeParse(req.query);
  const days   = query.success && query.data.days ? query.data.days : 30;

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);

  const readings = await db
    .select()
    .from(readingsTable)
    .where(eq(readingsTable.userId, userId))
    .orderBy(desc(readingsTable.recordedAt));

  const filtered = readings.filter((r) => new Date(r.recordedAt) >= cutoff);
  const byDay    = new Map<string, { systolics: number[]; diastolics: number[]; pulses: number[] }>();

  for (const r of filtered) {
    const date = new Date(r.recordedAt).toISOString().slice(0, 10);
    if (!byDay.has(date)) byDay.set(date, { systolics: [], diastolics: [], pulses: [] });
    const entry = byDay.get(date)!;
    entry.systolics.push(r.systolic);
    entry.diastolics.push(r.diastolic);
    if (r.pulse !== null) entry.pulses.push(r.pulse);
  }

  const trend = Array.from(byDay.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, { systolics, diastolics, pulses }]) => ({
      date,
      systolic:  Math.round((systolics.reduce( (s, v) => s + v, 0) / systolics.length)  * 10) / 10,
      diastolic: Math.round((diastolics.reduce((s, v) => s + v, 0) / diastolics.length) * 10) / 10,
      pulse: pulses.length > 0
        ? Math.round((pulses.reduce((s, v) => s + v, 0) / pulses.length) * 10) / 10
        : null,
    }));

  res.json(trend);
});

router.get("/dashboard/category-breakdown", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;

  const [user] = await db
    .select({ dateOfBirth: usersTable.dateOfBirth })
    .from(usersTable)
    .where(eq(usersTable.id, userId));

  const age = calcAge(user?.dateOfBirth ?? null);

  const readings = await db
    .select()
    .from(readingsTable)
    .where(eq(readingsTable.userId, userId));

  const counts = new Map<string, number>();
  for (const r of readings) {
    const cat = getBpCategory(r.systolic, r.diastolic, age);
    counts.set(cat, (counts.get(cat) ?? 0) + 1);
  }

  res.json(Array.from(counts.entries()).map(([category, count]) => ({
    category, count, color: getCategoryColor(category as any),
  })));
});

export default router;
