import { Router, type IRouter, type Request } from "express";
import { desc, eq, and, gte, lte } from "drizzle-orm";
import { db, readingsTable } from "../db/index.js";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";
import { getBpCategory, calcAge } from "../lib/bp-categories.js";
import { usersTable } from "../db/index.js";
import type { MedicationEntry } from "../db/schema/readings.js";

const router: IRouter = Router();

function escapeCsv(value: string | null | undefined): string {
  if (value == null) return "";
  const str = String(value);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function activityLabel(level: string | null): string {
  switch (level) {
    case "resting":  return "Resting";
    case "light":    return "Light activity";
    case "moderate": return "Moderate activity";
    case "exercise": return "Recently exercised";
    default:         return "";
  }
}

function medsLabel(meds: MedicationEntry[] | null): string {
  if (!meds || meds.length === 0) return "";
  return meds.map(m => m.dosage ? `${m.name} ${m.dosage}` : m.name).join("; ");
}

function parseDateRange(query: Record<string, unknown>): { from?: Date; to?: Date; error?: string } {
  let from: Date | undefined;
  let to: Date | undefined;
  if (query.from) {
    from = new Date(query.from as string);
    if (isNaN(from.getTime())) return { error: "Invalid 'from' date" };
    from.setHours(0, 0, 0, 0);
  }
  if (query.to) {
    to = new Date(query.to as string);
    if (isNaN(to.getTime())) return { error: "Invalid 'to' date" };
    to.setHours(23, 59, 59, 999);
  }
  if (from && to && from > to) return { error: "'from' must be before 'to'" };
  return { from, to };
}

router.get("/export/csv", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const { from, to, error } = parseDateRange(req.query as Record<string, unknown>);
  if (error) { res.status(400).json({ error }); return; }

  const [user] = await db.select({ dateOfBirth: usersTable.dateOfBirth }).from(usersTable).where(eq(usersTable.id, userId));
  const age = calcAge(user?.dateOfBirth ?? null);

  const conditions = [eq(readingsTable.userId, userId)];
  if (from) conditions.push(gte(readingsTable.recordedAt, from));
  if (to)   conditions.push(lte(readingsTable.recordedAt, to));

  const readings = await db
    .select()
    .from(readingsTable)
    .where(and(...conditions))
    .orderBy(desc(readingsTable.recordedAt));

  const header = [
    "Date", "Time",
    "Systolic (mmHg)", "Diastolic (mmHg)", "Pulse (bpm)",
    "Category",
    "Activity",
    "Medications Taken",
    "Notes",
  ].join(",");

  const rows = readings.map((r) => {
    const d = new Date(r.recordedAt);
    return [
      escapeCsv(d.toLocaleDateString("en-GB")),
      escapeCsv(d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })),
      r.systolic,
      r.diastolic,
      r.pulse ?? "",
      escapeCsv(getBpCategory(r.systolic, r.diastolic, age)),
      escapeCsv(activityLabel(r.activityLevel ?? null)),
      escapeCsv(medsLabel(r.medicationsTaken as MedicationEntry[] | null)),
      escapeCsv(r.notes),
    ].join(",");
  });

  const fromStr  = from ? `-from-${from.toISOString().slice(0, 10)}` : "";
  const toStr    = to   ? `-to-${to.toISOString().slice(0, 10)}`     : "";
  const filename = `bp-history${fromStr}${toStr}.csv`;

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.send("\uFEFF" + [header, ...rows].join("\n"));
});

export default router;
