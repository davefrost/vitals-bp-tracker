import { Router, type IRouter } from "express";
import healthRouter      from "./health.js";
import readingsRouter    from "./readings.js";
import dashboardRouter   from "./dashboard.js";
import authRouter        from "./auth.js";
import exportRouter      from "./export.js";
import pdfExportRouter   from "./pdf-export.js";
import accountRouter     from "./account.js";
import adminRouter       from "./admin.js";
import medicationsRouter from "./medications.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(readingsRouter);
router.use(dashboardRouter);
router.use(exportRouter);
router.use(pdfExportRouter);
router.use(accountRouter);
router.use(adminRouter);
router.use(medicationsRouter);

export default router;
