import { Router, type IRouter, type Request } from "express";
import { eq, and } from "drizzle-orm";
import { db, medicationsTable } from "../db/index.js";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";
import { FREQUENCY_OPTIONS, TIME_OF_DAY_OPTIONS } from "../db/schema/medications.js";

const router: IRouter = Router();

function validateMedFields(body: Record<string, unknown>): {
  name?: string; dosage?: string | null;
  frequency?: string | null; timeOfDay?: string | null;
  startDate?: string | null; notes?: string | null;
  error?: string;
} {
  const { name, dosage, frequency, timeOfDay, startDate, notes } = body;

  if (name !== undefined) {
    if (typeof name !== "string" || name.trim().length === 0 || name.length > 100)
      return { error: "Name must be a non-empty string under 100 characters" };
  }

  if (frequency !== undefined && frequency !== null && frequency !== "") {
    if (!FREQUENCY_OPTIONS.includes(frequency as typeof FREQUENCY_OPTIONS[number]))
      return { error: `Invalid frequency value` };
  }

  if (timeOfDay !== undefined && timeOfDay !== null && timeOfDay !== "") {
    if (!TIME_OF_DAY_OPTIONS.includes(timeOfDay as typeof TIME_OF_DAY_OPTIONS[number]))
      return { error: `Invalid time of day value` };
  }

  if (startDate !== undefined && startDate !== null && startDate !== "") {
    if (typeof startDate !== "string" || isNaN(Date.parse(startDate)))
      return { error: "Invalid start date" };
  }

  return {
    name:      typeof name     === "string" ? name.trim()         : undefined,
    dosage:    typeof dosage   === "string" ? dosage.trim() || null  : null,
    frequency: typeof frequency === "string" ? frequency || null    : null,
    timeOfDay: typeof timeOfDay === "string" ? timeOfDay || null    : null,
    startDate: typeof startDate === "string" ? startDate || null    : null,
    notes:     typeof notes    === "string" ? notes.trim() || null  : null,
  };
}

router.get("/medications", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;

  const meds = await db
    .select()
    .from(medicationsTable)
    .where(and(eq(medicationsTable.userId, userId), eq(medicationsTable.active, true)))
    .orderBy(medicationsTable.createdAt);

  res.json(meds);
});

router.post("/medications", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const validated = validateMedFields(req.body as Record<string, unknown>);

  if (validated.error) { res.status(400).json({ error: validated.error }); return; }
  if (!validated.name)  { res.status(400).json({ error: "Name is required" }); return; }

  const [med] = await db
    .insert(medicationsTable)
    .values({
      userId,
      name:      validated.name,
      dosage:    validated.dosage    ?? null,
      frequency: validated.frequency ?? null,
      timeOfDay: validated.timeOfDay ?? null,
      startDate: validated.startDate ?? null,
      notes:     validated.notes     ?? null,
    })
    .returning();

  res.status(201).json(med);
});

router.patch("/medications/:id", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const medId  = parseInt(req.params.id, 10);
  if (isNaN(medId)) { res.status(400).json({ error: "Invalid medication ID" }); return; }

  const validated = validateMedFields(req.body as Record<string, unknown>);
  if (validated.error) { res.status(400).json({ error: validated.error }); return; }

  const updates: Partial<typeof medicationsTable.$inferInsert> = {};
  if (validated.name      !== undefined) updates.name      = validated.name;
  if (validated.dosage    !== undefined) updates.dosage    = validated.dosage;
  if (validated.frequency !== undefined) updates.frequency = validated.frequency;
  if (validated.timeOfDay !== undefined) updates.timeOfDay = validated.timeOfDay;
  if (validated.startDate !== undefined) updates.startDate = validated.startDate;
  if (validated.notes     !== undefined) updates.notes     = validated.notes;

  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "No valid fields to update" }); return;
  }

  const [updated] = await db
    .update(medicationsTable)
    .set(updates)
    .where(and(eq(medicationsTable.id, medId), eq(medicationsTable.userId, userId)))
    .returning();

  if (!updated) { res.status(404).json({ error: "Medication not found" }); return; }
  res.json(updated);
});

router.delete("/medications/:id", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const medId  = parseInt(req.params.id, 10);
  if (isNaN(medId)) { res.status(400).json({ error: "Invalid medication ID" }); return; }

  const [updated] = await db
    .update(medicationsTable)
    .set({ active: false })
    .where(and(eq(medicationsTable.id, medId), eq(medicationsTable.userId, userId)))
    .returning({ id: medicationsTable.id });

  if (!updated) { res.status(404).json({ error: "Medication not found" }); return; }
  res.sendStatus(204);
});

export default router;
