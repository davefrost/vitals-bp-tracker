import { Router, type IRouter, type Request } from "express";
import { desc, eq, and } from "drizzle-orm";
import { db, readingsTable } from "../db/index.js";
import {
  CreateReadingBody,
  UpdateReadingBody,
  GetReadingParams,
  UpdateReadingParams,
  DeleteReadingParams,
  ListReadingsQueryParams,
} from "../validation/index.js";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

router.get("/readings", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const query = ListReadingsQueryParams.safeParse(req.query);
  const limit = query.success && query.data.limit ? query.data.limit : 100;
  const offset = query.success && query.data.offset ? query.data.offset : 0;

  const readings = await db
    .select()
    .from(readingsTable)
    .where(eq(readingsTable.userId, userId))
    .orderBy(desc(readingsTable.recordedAt))
    .limit(limit)
    .offset(offset);

  res.json(readings);
});

router.post("/readings", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const parsed = CreateReadingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [reading] = await db
    .insert(readingsTable)
    .values({
      userId,
      systolic: parsed.data.systolic,
      diastolic: parsed.data.diastolic,
      pulse: parsed.data.pulse ?? null,
      notes: parsed.data.notes ?? null,
      recordedAt: new Date(parsed.data.recordedAt),
      activityLevel: parsed.data.activityLevel ?? null,
      medicationsTaken: parsed.data.medicationsTaken ?? null,
    })
    .returning();

  res.status(201).json(reading);
});

router.get("/readings/:id", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const params = GetReadingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [reading] = await db
    .select()
    .from(readingsTable)
    .where(and(eq(readingsTable.id, params.data.id), eq(readingsTable.userId, userId)));

  if (!reading) {
    res.status(404).json({ error: "Reading not found" });
    return;
  }

  res.json(reading);
});

router.patch("/readings/:id", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const params = UpdateReadingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateReadingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Partial<typeof readingsTable.$inferInsert> = {};
  if (parsed.data.systolic    !== undefined) updateData.systolic    = parsed.data.systolic;
  if (parsed.data.diastolic   !== undefined) updateData.diastolic   = parsed.data.diastolic;
  if (parsed.data.pulse       !== undefined) updateData.pulse       = parsed.data.pulse;
  if (parsed.data.notes       !== undefined) updateData.notes       = parsed.data.notes;
  if (parsed.data.recordedAt  !== undefined) updateData.recordedAt  = new Date(parsed.data.recordedAt);
  if (parsed.data.activityLevel    !== undefined) updateData.activityLevel    = parsed.data.activityLevel;
  if (parsed.data.medicationsTaken !== undefined) updateData.medicationsTaken = parsed.data.medicationsTaken;

  const [reading] = await db
    .update(readingsTable)
    .set(updateData)
    .where(and(eq(readingsTable.id, params.data.id), eq(readingsTable.userId, userId)))
    .returning();

  if (!reading) {
    res.status(404).json({ error: "Reading not found" });
    return;
  }

  res.json(reading);
});

router.delete("/readings/:id", requireAuth, async (req: Request, res): Promise<void> => {
  const userId = (req as AuthenticatedRequest).userId;
  const params = DeleteReadingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [reading] = await db
    .delete(readingsTable)
    .where(and(eq(readingsTable.id, params.data.id), eq(readingsTable.userId, userId)))
    .returning();

  if (!reading) {
    res.status(404).json({ error: "Reading not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
