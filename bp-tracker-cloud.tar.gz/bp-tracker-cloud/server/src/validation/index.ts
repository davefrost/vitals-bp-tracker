import * as zod from "zod";

export const ACTIVITY_LEVELS = ["resting", "light", "moderate", "exercise"] as const;

export const MedicationEntrySchema = zod.object({
  name: zod.string().min(1).max(100),
  dosage: zod.string().max(50).nullish(),
});

export const ListReadingsQueryParams = zod.object({
  limit: zod.coerce.number().optional(),
  offset: zod.coerce.number().optional(),
});

export const CreateReadingBody = zod.object({
  systolic: zod.number(),
  diastolic: zod.number(),
  pulse: zod.number().nullish(),
  notes: zod.string().nullish(),
  recordedAt: zod.coerce.date(),
  activityLevel: zod.enum(ACTIVITY_LEVELS).nullish(),
  medicationsTaken: zod.array(MedicationEntrySchema).nullish(),
});

export const GetReadingParams = zod.object({
  id: zod.coerce.number(),
});

export const UpdateReadingParams = zod.object({
  id: zod.coerce.number(),
});

export const UpdateReadingBody = zod.object({
  systolic: zod.number().optional(),
  diastolic: zod.number().optional(),
  pulse: zod.number().nullish(),
  notes: zod.string().nullish(),
  recordedAt: zod.coerce.date().optional(),
  activityLevel: zod.enum(ACTIVITY_LEVELS).nullish(),
  medicationsTaken: zod.array(MedicationEntrySchema).nullish(),
});

export const DeleteReadingParams = zod.object({
  id: zod.coerce.number(),
});

export const GetReadingTrendQueryParams = zod.object({
  days: zod.coerce.number().optional(),
});

export const HealthCheckResponse = zod.object({
  status: zod.string(),
});
